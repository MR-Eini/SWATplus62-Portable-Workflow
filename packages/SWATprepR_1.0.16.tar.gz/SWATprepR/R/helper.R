
# Miscellaneous --------------------------------------------------------------------

#' Prepare water balance table
#' 
#' This function reads data from 'basin_wb_aa.txt' and 'basin_aqu_aa.txt' 
#' SWAT+ model output files and prepares various water balance parameters table.
#' 
#' @param project_path The path to the directory containing SWAT+ output files.
#' @return A data frame containing water balance parameters
#' @importFrom dplyr select bind_rows rename filter
#' @export
#' @examples
#' \dontrun{
#' df <- wbalance_table("path/to/project")
#' write.csv(df, "water_balance.csv", row.names = FALSE, quote = FALSE)
#' }

wbalance_table <- function(project_path){
  
  # Read data from files
  basin_wb_aa   <- read_tbl('basin_wb_aa.txt', project_path, 4)
  basin_aqu_aa  <- read_tbl('basin_aqu_aa.txt',  project_path, 4) 
  
  # Compute extract parameters
  wb_aa  <- round(unlist(basin_wb_aa[,c(8:12, 14:18, 20:23, 27:32, 34:39, 43)]), 2) 
  aqu_aa <- round(unlist(basin_aqu_aa[,c(8:10, 12:13, 22:24)]), 2) 
  
  ## Calculate the water balance parameters
  if (aqu_aa['flo_cha'] == 0 & aqu_aa['flo_res'] == 0 & aqu_aa['flo'] > 0) {
    aqu_flo <- aqu_aa['flo']
  } else {
    aqu_flo <- aqu_aa['flo_cha'] + aqu_aa['flo_res']
  }
  
  surq <- wb_aa['surq_cha'] + wb_aa['surq_res']
  
  base <- wb_aa['latq_cha'] + wb_aa['latq_res'] +
    aqu_flo + wb_aa['qtile']
  
  wyld <- surq + base
  
  ratios <- round(c(wb_aa['et'] / wb_aa['precip'], wyld / wb_aa['precip'],
                    surq / wyld, base / wyld, surq, base, wyld), 2)
  
  ratios <- as.data.frame(ratios) %>% 
    rename(Value = 1)
  row.names(ratios ) <- c('et / precip: ', 'wyld / precip:', 'surq / wyld:', 'base / wyld: ',
                          paste0('surq = surq_cha + surq_res:'),
                          paste0('base = latq_cha + latq_res + qtile'),
                          paste0('wyld = surq + base:'))
  
  ## Combine into one dataframe
  df <- bind_rows(as.data.frame(wb_aa)%>% rename(Value = 1), 
                  as.data.frame(aqu_aa) %>% rename(Value = 1), 
                  ratios)
  df$Parameter <- rownames(df)
  rownames(df) <- NULL
  df <- select(df, Parameter, Value) %>% 
    filter(!Parameter %in% c('flo_cha', 'flo_res', 'flo_ls')) %>%
  
  return(df)
}

#' Read information about model setup from SWAT files
#'
#' This function reads setup information from SWAT files in the specified project path.
#'
#' @param project_path The path to the project directory containing SWAT setup files.
#' 
#' @return A data frame containing setup information extracted from SWAT files.
#' @importFrom dplyr select filter starts_with rename mutate
#' @importFrom tibble rownames_to_column
#' @examples
#' \dontrun{
#' df <- setup_info("/path/to/project")
#' write.csv(df, "write_path/table.csv", row.names = FALSE, quote = FALSE)
#' }
#' @export

setup_info <- function(project_path){
  df <- read_tbl("object.cnt", project_path)
  plant_nb <- suppressWarnings(read_tbl("plant.ini", project_path)) %>% 
    select(pcom_name) %>% 
    filter(!grepl("_comm|orcd",pcom_name)) %>% 
    unique %>% 
    nrow
  wetlant_nb <- df_plant <- read_tbl("wetland.wet", project_path) %>% 
    nrow
  
  colnames(df) <- c("Name of the watershed", 
                    "Land area of the watershed in ha",
                    "Total area of the watershed in ha",
                    "Total number of spatial objects in the simulation",
                    "Number of HRUs in the simulation",
                    "Number of HRU-ltes in the simulation",
                    "Number of routing units in the simulation",
                    "Number of gwflow river cells",
                    "Number of aquifers in the simulation",
                    "Unused1",
                    "Number of reservoirs in the simulation",
                    "Number of recalls (point sources/inlets) in the simulation",
                    "Number of export coefficients in the simulation",
                    "Number of delivery ratios in the simulation",
                    "Unused2",
                    "Unused3",
                    "Number of outlets in the simulation",
                    "Number of SWAT-DEG channels in the simulation",
                    "Unused4",
                    "Unused5",
                    "Unused6")
  df <- select(df, -starts_with("Unused")) %>% 
    select(-starts_with("Land"))
  
  df <- data.frame(t(df[,-1])) %>% 
    tibble::rownames_to_column("Parameter")%>% 
    rename(Value = 2) %>% 
    filter(Value > 0) %>% 
    mutate(Value = as.integer(Value))
  
  df[nrow(df) + 1,] = c("Number of crops in rotation", plant_nb)
  df[nrow(df) + 1,] = c("Number of wetlands", wetlant_nb)
  
  return(df)
}

#' Find Differences Between Files in Two Setups
#'
#' This function scans two folders and identifies files that exist only in one 
#' setup or files with differences between setups. The function requires the 
#' `diffr` package to be installed.
#'
#' @param path1 Path to the first setup.
#' @param path2 Path to the second setup.
#' @param name1 Character for name for the first setup (default is \code{name1 = Setup 1}).
#' @param name2 Character for name for the second setup (default is \code{name2 = Setup 2}).
#' @param remove_pattern Regex pattern for files to be removed. Default is \code{remove_pattern = NULL}, 
#' which means pattern removes file types: txt, zip, fin, out, exe, bak, mgts, 
#' farm, sqlite, swf, sch, hmd, wnd, pcp, slr, tmp. Example for excluding only txt files  \code{remove_pattern <- '.*.txt'}. 
#' Other can be added using | operator.   
#' @return A list containing differences between files if found, otherwise a message indicating no differences.
#' @importFrom dplyr symdiff
#' @export

find_dif <- function(path1, path2, name1 = "Setup 1", name2 = "Setup2", remove_pattern = NULL){
  ## Default remove pattern
  if(is.null(remove_pattern)){
    remove_pattern <- ".*.txt|.*.zip|.*.fin|.*.out|.*.exe|.*.bak|.*.mgts|.*.farm|.*.sqlite|.*.swf|.*.sch|.*.hmd|.*.wnd|.*.pcp|.*.slr|.*.tmp"
  }
  
  ## Scan folders
  v_new <- setdiff(list.files(path1), list.files(path1, pattern = remove_pattern))
  v_old <- setdiff(list.files(path2), list.files(path2, pattern = remove_pattern))
  
  ## Different files (doesn't exist in old or new setup)
  v_diff <- symdiff(v_new, v_old)
  
  ## Find if there are any different files
  if(length(v_diff) > 0) message("File/s " , paste0(v_diff, collapse = ", "), " exists only in one of setups!!!")
  
  ## Common files to be used in the loop
  v_files <- v_new[v_new %in% v_old]
  
  ## Loop over files
  #List to save differences
  l <- list()
  for (f in v_files){
    file1 <- paste0(path1, "/", f)
    file2 <- paste0(path2, "/", f)
    if(any(readLines(file1)[-1] != readLines(file2)[-1])){
      message(paste0("Difference in file ", f))
      if (!requireNamespace("diffr", quietly = TRUE)) {
        stop("diffr package is not installed. 'find_dif' function requires 
                diffr package to show differences. Please install diffr package 
                to see differences.")
      }
      l[[f]] <- diffr::diffr(file1, file2, before = name1, after = name2)
    }
  }
  if(length(l) == 0){
    message("No differences found")
  } else {
    message("Differences found in ", length(l), " files")
    return(l)
  }
}

#' Function to put option remove hide or show all lines in chart and this function also print chart.
#'
#' @param graph plotly graph object
#' @importFrom plotly plotly_build layout
#' @return plotly graph object with option to remove or show all lines
#' @keywords internal
#'
#' @examples
#' \dontrun{
#' hide_show(fig)
#' }

hide_show <- function(graph){
  plotly_build(graph) %>%
    layout(updatemenus = list(
      list(type = "buttons", direction = "right", xanchor = "center", yanchor = "top", 
           showactive = FALSE, x = 0.3, y = 1.0,
           buttons = list(
             list(method = "restyle",
                  args = list("visible", "all"),
                  label = "show all"),
             list(method = "restyle",
                  args = list("visible", "legendonly"),
                  label = "hide all")))))
}

#' Function to get maximum min and max dates available for all time series data for all stations for all parameters. 
#'
#' @param meteo_lst nested list of lists with dataframes. 
#' Nested structure meteo_lst -> data -> Station ID -> Parameter -> Dataframe (DATE, PARAMETER).
#' @importFrom lubridate now
#' @return list with 2 values: minimum and maximum value for all available data.
#' @keywords internal
#'
#' @examples
#' \dontrun{
#' get_dates(meteo_lst)
#' }

get_dates <- function(meteo_lst){
  meteo_lst <- meteo_lst$data
  min_date <- min(meteo_lst[[1]][[1]]$DATE)
  max_date <- max(meteo_lst[[1]][[1]]$DATE)
  for (n in names(meteo_lst)){
    for(p in names(meteo_lst[[n]])){
      if(min_date >= min(meteo_lst[[n]][[p]]$DATE)){
        min_date <-  min(meteo_lst[[n]][[p]]$DATE)
      }
      if(max_date <= max(meteo_lst[[n]][[p]]$DATE)){
        max_date <-  max(meteo_lst[[n]][[p]]$DATE)
      }
    }
  }
  ##Returning a list of two dates
  return(list(min_date = min_date, max_date = max_date))
}


#' Getting number of stations with data for selected parameter
#' 
#' @param meteo_lst nested list of lists with dataframes. 
#' Nested structure meteo_lst -> data -> Station ID -> Parameter -> Dataframe (DATE, PARAMETER).
#' @param par is weather variable to extract (i.e. "PCP", "SLR", etc)
#' @return number of stations with data for this parameter. 
#' @keywords internal
#'
#' @examples
#' \dontrun{
#' get_nb_st_with_data(meteo_lst, "PCP")
#' }

get_nb_st_with_data <- function(meteo_lst, par){
  meteo_lst <- meteo_lst$data
  i <- 0
  for (n in names(meteo_lst)){
    if(par %in% names(meteo_lst[n][[1]])){
      i <- i+1
    }
  }
  return(i)
}

#' Count number of years data available for variable
#'
#' @param df dataframe with DATE column and at least one variable column.
#' @param col variable column name
#' @importFrom lubridate year
#' @return numeric number on year for which data is available. 
#' @keywords internal
#'
#' @examples
#' \dontrun{
#' nyears(df, "PCP")
#' }

nyears <- function(df, col){
  ts <- df$DATE[!is.na(df[[col]])]
  max(year(ts))-min(year(ts))+1
}

#' Get min Ks within depth range from SOL_K and SOL_Z
#'
#' @param df one row dataframe of soil parameters with all SOL_K and SOL_Z columns
#' @param max_depth numeric value for depth range from 0.  
#' @return numeric min Ks parameter value within depth range
#' @keywords internal
#'
#' @examples
#' \dontrun{
#' df <- data.frame(SOL_K1 = 10, SOL_K2 = 1, SOL_K3 = 2, 
#'                  SOL_Z1 = 250, SOL_Z2 = 700, SOL_Z3 = 1000)
#' min_ks(df, 800)
#' }

min_ks <- function(df, max_depth){
  ind <- as.vector(grep("SOL_K", colnames(df))[df[,grep("SOL_Z", colnames(df))] < max_depth])
  if(length(ind) > 1){
    ind <- c(ind, ind[-1] + 1)
  } else if (length(ind) == 1){
    ind <- c(ind, ind + 1)
  } else if (max_depth > 0){
    ind <- 1
  }
  return((min(df[,ind])/0.4167)/8.64)
}

#' Identify time step 
#'
#' @param d_after single value data frame with later date 
#' @param d_before single value data frame with earlier date 
#' @return list with 'typ' code and 'rec_typ' code
#' @keywords internal
#' @examples
#' \dontrun{
#' find_time_step(r[2, "DATE"], r[1, "DATE"])
#' }

find_time_step <- function(d_after, d_before){
  t_diff <- d_after - d_before
  u_diff <- units(t_diff$DATE)
  t_diff <- as.numeric(d_after - d_before)
  if(u_diff == "days"){
    if(t_diff >= 62){
      typ <- "yr"
      rec_typ <- 3
    } else if(is.na(t_diff)){
      typ <- "aa"
      rec_typ <- 3
    } else if(t_diff > 1 & t_diff < 62){
      typ <- "mo"
      rec_typ <- 2
    } else if ((t_diff = 1)){
      typ <- "dy"
      rec_typ <- 1
    } else {
      stop("Please check dates as no time step could be identified!!!")
    }
  } else if (u_diff %in% c("hours", "minutes", "seconds")){
    typ <- "sd"
    rec_typ <- 0
  } else {
    stop("Please check dates as no time step could be identified!!!")
  }
  return(list(typ = typ, rec_typ = rec_typ))
}

# Interpolation --------------------------------------------------------------------

#' Prepare grid for interpolation
#'
#' @param b  vector of border c(xmin, ymin, xmax, ymax) coordinates to define extent of the grid.
#' @param grid_spacing Grid spacing. Depending on coordinate system could be in meters, or degrees.
#' @param wkt_str projection string
#' @importFrom sf st_crs
#' @return Grid needed for the interpolation. 
#' @keywords internal
#'
#' @examples
#' \dontrun{
#' get_grid(shp, 2000, wkt_str)
#' }

get_grid <- function(b, grid_spacing, wkt_str){
  x.range <- c(b[1]*0.999,b[3]*1.001)
  y.range <- c(b[2]*0.999,b[4]*1.001)
  grd <- expand.grid(x = seq(from = x.range[1], to = x.range[2], by = grid_spacing), y = seq(from = y.range[1], to = y.range[2], by = grid_spacing)) 
  sp::coordinates(grd) <- c("x", "y")
  sp::gridded(grd)     <- TRUE
  sp::fullgrid(grd)    <- TRUE
  suppressWarnings(sp::proj4string(grd) <-  sp::CRS(SRS_string = wkt_str))
  return(grd)
}

#' Get interpolation values for catchment
#'
#' @param sp_df SpatialPointsDataFrame with one column for one day and rows as stations.
#' @param st SpatialPointsDataFrame with virtual stations from a grid. Should contain
#' dataframe in data for station elevation from DEM  
#' @param grd Grid for interpolation.
#' @param i integer representing day number.
#' @param idw_exponent numeric value for exponent parameter to be used in interpolation. 
#' @return SpatialPointsDataFrame with virtual stations and interpolated data in data dataframe
#' @keywords internal
#'
#' @examples
#' \dontrun{
#' get_interpolation(sp_df, meteo_pts, 2, 2)
#' }

get_interpolation <- function(sp_df, st, grd, i, idw_exponent){
  if(sum(is.na(sp_df@data[1])) != dim(sp_df@data[1])[[1]]){
    if(sum(is.na(sp_df@data[1])) != 0){
      sp_df <- sp.na.omit(sp_df)
    }
    colnames(sp_df@data) <- "v"
    idw <- gstat::idw(v ~ 1, sp_df, newdata=grd, idp=idw_exponent, debug.level = 0)
    r <- raster::raster(idw)
    r <- raster::extract(r, st)
    st@data[as.character(i)] <- r
  } else {
    st@data[as.character(i)] <- NA
  }
  return(st)
}

#' Function to remove NAs in sp dataframe
#'
#' @param x sp dataframe
#' @param margin numeric. Optional, default 1 for remove rows, 2 for removing columns.
#'
#' @return sp dataframe without NAs in data 
#' @keywords internal
#'
#' @examples
#' \dontrun{
#' sp_df <- sp.na.omit(sp_df)
#' }

sp.na.omit <- function(x, margin=1) {
  if (!inherits(x, "SpatialPointsDataFrame") & !inherits(x, "SpatialPolygonsDataFrame")) 
    stop("MUST BE sp SpatialPointsDataFrame OR SpatialPolygonsDataFrame CLASS OBJECT") 
  na.index <- unique(as.data.frame(which(is.na(x@data),arr.ind=TRUE))[,margin])
  ##Deleting rows
  if(margin == 1) {  
    return( x[-na.index,]  ) 
  }
  ##Deleting columns
  if(margin == 2) {  
    return( x[,-na.index]  ) 
  }
}

# Writing -----------------------------------------------------------------

#' Transforming sp dataframe to dataframe
#'
#' @param sp_df sp dataframe
#' @importFrom dplyr %>% mutate_if
#' @return Dataframe prepared for being written out. 
#' @keywords internal
#'
#' @examples
#' \dontrun{
#' df_t(sp_df)
#' }

df_t <- function(sp_df){
  ##Preparing time series files and writing them into output folder
  df <- sp_df@data[,-1]
  # df[is.na(df)] <- -99 ##Changing NA to -99 for weather generator
  as.data.frame(t(df)) %>%
    mutate_if(is.numeric, ~round(., 3))
}

#' Transforming list of sp dataframes to list of list 
#'
#' @param list_sp a list of SpatialPointsDataFrames (for each weather variable) 
#' prepared with  \code{\link{interpolate}} function.
#' @param start_date time series starting date string. Example "1998-01-01".
#' @param end_date time series ending date string. Example "2021-12-31".
#' @importFrom dplyr %>% bind_cols
#' @importFrom tibble as_tibble
#' @importFrom sf st_as_sf
#' @return meteo_lst nested list of lists with dataframes. 
#' Nested structure meteo_lst -> data -> Station ID -> Parameter -> Dataframe (DATE, PARAMETER).
#' Nested meteo_lst -> stations Dataframe (ID, Name, Elevation, Source, geometry, Long, Lat).
#' @keywords internal
#' @examples
#' \dontrun{
#' ###First step to get interpolation results
#' temp_path <- system.file("extdata", "weather_data.xlsx", package = "SWATprepR")
#' DEM_path <- system.file("extdata", "GIS/DEM.tif", package = "SWATprepR")
#' basin_path <- system.file("extdata", "GIS/basin.shp", package = "SWATprepR")
#' met_lst <- load_template(temp_path, 3035)
#' result <- interpolate(met_lst, "./output/",  basin_path, DEM_path, 2000) 
#' 
#' ###Second step converting interpolation results to list of list format.
#' start_date <- SWATprepR:::get_dates(met_lst)$min_date
#' end_date <- SWATprepR:::get_dates(met_lst)$max_date
#' int_met_lst <- transform_to_list(result, start_date, end_date)
#' }

transform_to_list <- function(list_sp, start_date, end_date){
  df <- data.frame(DATE = seq(as.POSIXct(start_date, "%Y-%m-%d", tz = "UTC"),
                              as.POSIXct(end_date, "%Y-%m-%d", tz = "UTC"), by = "day"))
  r <- list()
  r[["stations"]] <- data.frame(ID = paste0("ID", 1:dim(list_sp[[1]]@data)[[1]]),
                                Name = paste0("ID", 1:dim(list_sp[[1]]@data)[[1]]),
                                Elevation = list_sp[[1]]$DEM,
                                Source = "Interpolation",
                                geometry = st_as_sf(list_sp[[1]]@coords %>% 
                                                      as.data.frame, 
                                                    coords = c("x", "y"), 
                                                    crs = list_sp[[1]]@proj4string@projargs),
                                Long = list_sp[[1]]@coords[,1],
                                Lat = list_sp[[1]]@coords[,2]) %>% 
    as_tibble() %>% 
    st_as_sf()
  for (p in c("PCP", "SLR", "RELHUM", "WNDSPD", "TMP_MAX", "TMP_MIN")){
    if(p %in% names(list_sp)){
      y <- df_t(list_sp[[p]])
      names(y) <- rep(p, dim(y)[2])
      for(i in 1:ncol(y)){
        r[["data"]][[paste0("ID", i)]][[p]] <- bind_cols(df["DATE"], y[i])
      }
    } else {
      warning(paste(p, "variable is missing. Please add it later."))
    }
  }
  return(r)
}

#' Transforming list to dataframe
#'
#' @param lst nested list dataframes (for each weather variable)
#' @importFrom dplyr full_join
#' @return dataframe with all collected dataframes in single dataframe. 
#' @keywords internal
#' @examples
#' \dontrun{
#' temp_path <- system.file("extdata", "weather_data.xlsx", package = "SWATprepR")
#' met_lst <- load_template(temp_path, 3035)
#' df <- list_to_df(met_lst$data$ID1)
#' }

list_to_df <- function(lst){
  df <- NULL
  for (p in names(lst)){
    if(!is.null(df)){
      df <- full_join(df, lst[[p]], by = "DATE")
    } else {
      df <- lst[[p]]
    }
  }
  arrange(df, DATE)
}


#' Updating SWAT+ SQLite database table with wst_id information
#'
#' @param tname character of table name (example "hru_con")
#' @param db_path character to SWAT+ SQLite database (example "./output/project.sqlite")
#' @param wst_cli data.frame weather_sta_cli table
#' @importFrom DBI dbConnect dbReadTable dbWriteTable dbDisconnect
#' @importFrom RSQLite SQLite
#' @importFrom sf st_as_sf st_nearest_feature
#' @return updates sql database with table amended with wst_id (id of closest weather station)
#' @keywords internal
#' @examples
#' \dontrun{
#' update_wst_id("hru_con", "./output/project.sqlite", weather_sta_cli)
#' }

update_wst_id <- function(tname, db_path, wst_cli){
  db <- dbConnect(RSQLite::SQLite(), db_path)
  t <- dbReadTable(db, tname)
  t_sf <- st_as_sf(t, coords = c("lon", "lat"), crs = 4326)
  wst_sf <- st_as_sf(wst_cli, coords = c("lon", "lat"), crs = 4326)
  ##Finding wst_id of nearest station
  t$wst_id <- wst_cli[st_nearest_feature(t_sf, wst_sf),"id"]
  dbWriteTable(db, tname, t, overwrite = TRUE)
  dbDisconnect(db)
  return(print(paste(tname, "updated with wst_id and rewritten into database.")))
}

#' Updating wst_id information in model text files
#'
#' @param fname character, model file name (example 'aquifer.con').
#' @param write_path character, path to SWAT+ txtinout folder (example "my_model").
#' @param wst_sf sf dataframe with weather station information. Should contain "name" and "geometry" columns. 
#' @param spacing character, should contain information about spacing between columns in the file. 
#' Example c('%8s', '%-12s', rep('%12s', 5), '%8s', '%16s', rep('%8s', 4)).
#' @param folder_to_save character, folder to save function results. Optional, \code{default = "temp"}.
#' @importFrom dplyr mutate_at vars one_of
#' @importFrom sf st_as_sf st_nearest_feature
#' @importFrom purrr map2_df
#' @importFrom stringr str_replace_all
#' @importFrom readr write_lines
#' @importFrom tidyr replace_na
#' @return Updated text file, which would have updated station names 
#' (with nearest stations to features). 
#' @export
#' 
#' @examples
#' \dontrun{
#' spacing <- c('%8s', '%-12s', rep('%12s', 5), '%8s', '%16s', 
#' rep('%8s', 4), '%12s', '%8s', rep('%12s', 2))
#' update_wst_txt("reservoir.con", "model_folder", wst_sf, spacing)
#' }
#' @keywords internal

update_wst_txt <- function(fname, write_path, wst_sf, spacing, folder_to_save = "temp"){
  ##Making heading text
  text_l <-  paste0(fname,": ", "rewritten by SWATprepR R package ", Sys.time(), " for SWAT+ rev.60.5.4")
  ##Reading file into dataframe
  f <- read_tbl(fname, write_path, 3, 2) %>% 
    mutate_at(vars(one_of(c("area", "lat", "lon", "elev", "frac"))), ~format(round(as.numeric(.), 5), nsmall = 5)) %>% 
    suppressWarnings()
  ##Finding nearest weather station and updating info in file with this info 
  f_sf <- st_as_sf(f, coords = c("lon", "lat"), crs = 4326)
  f$wst <-  wst_sf$name[st_nearest_feature(f_sf, wst_sf)]
  ##Preparing column name line
  ##To deal with irregular tables (not same number of column names and columns)
  f_names <- colnames(f) %>% 
    .[!grepl("vvv", .)] %>%
    map2_chr(., spacing[c(1:length(.))] %>% replace_na(spacing[length(spacing)]), ~sprintf(.y, .x)) %>% 
    paste(., collapse = '  ') 
  ##Preparing all other lines
  if(length(spacing) - dim(f)[2]<0){
    spacing <- c(spacing, rep(spacing[length(spacing)], dim(f)[2] - length(spacing)))
  } else if(length(spacing) - dim(f)[2]>0){
    spacing <- spacing[c(1:dim(f)[2])]
  }
  f_lines <- f %>%
    map2_df(., spacing, ~sprintf(.y, .x)) %>%
    apply(., 1, paste, collapse = '  ') %>% 
    str_replace_all("NA", "") ##Removing NAs
  ##Creating temp directory to to save results 
  f_dir <- paste(write_path, folder_to_save, sep = '/')
  f_write <- paste(f_dir, fname, sep = '/')
  if(!dir.exists(f_dir)){
    dir.create(f_dir)
  } 
  if(!file.exists(f_write)){
    file.create(f_write)
  } else {
    unlink(f_write)
    file.create(f_write)
  }
  ##Writing results into temp directory
  write_lines(c(text_l, f_names, f_lines), f_write)
  print(paste0("Updated weather stations in ", fname, " file."))
}

#' Write weather meteo_lst into template .xlsx file. 
#' 
#' The function requires the `openxlsx` package to be installed.
#'
#' @param meteo_lst nested list of lists with dataframes. 
#' Nested structure meteo_lst -> data -> Station ID -> Parameter -> Dataframe (DATE, PARAMETER).
#' @param write_path (optional) character path to folder where results should be written (default "").
#' @param f_name (optional) character name of the file (default 'weather_data.xlsx'). 
#' @importFrom sf st_drop_geometry
#' @importFrom dplyr %>% select full_join arrange mutate
#' @return .xlsx file written in template format, which could de read by \code{\link{load_template}} function.
#' @keywords internal
#' @examples
#' \dontrun{
#' write_weather_template(met_lst)
#' }

write_weather_template <- function(meteo_lst, write_path = "", f_name = "weather_data.xlsx"){
  ## Checking if openxlsx is installed
  if(!requireNamespace("openxlsx", quietly = TRUE)){
    stop("openxlsx package is not installed. 'write_weather_template' function requires 
                openxlsx package to write data into .xlsx file. Please install openxlsx package")
  }
  ##Removing existing file if in path
  f <- paste0(write_path, f_name)
  ##Writing station info
  getOption("openxlsx.dateFormat", "YYYY-MM-DD")
  wb <- openxlsx::createWorkbook()
  openxlsx::addWorksheet(wb, "Stations")
  openxlsx::writeData(wb, "Stations", as.data.frame(meteo_lst$stations %>% 
                                            st_drop_geometry %>%
                                            select(ID, Name, Elevation, Source, Long, Lat)))
  ##Writing data
  dt <- meteo_lst$data
  for (n in names(dt)){
    df <- NULL
    print(paste0("Working on station ", n))
    for (par in names(dt[[n]])){
      if(is.null(df)){
        df <- dt[[n]][[par]]
      } else {
        df <- df %>%
          full_join(dt[[n]][[par]], by = "DATE")
      }
    }
    openxlsx::addWorksheet(wb, n)
    openxlsx::writeData(wb, n, as.data.frame(df %>% 
                                     mutate(DATE = as.Date(DATE)) %>%
                                     arrange(DATE)))
  }
  openxlsx::saveWorkbook(wb, f, overwrite = TRUE)
  return(paste0("Writing was successful. Your file is in ", f))
}

#' Transform dataframe into text and writes into existing file
#'
#' @param write_path  character, path to SWAT+ txtinout folder (example "my_model").
#' @param fname character, file name.
#' @param df dataframe 
#' @param spacing character, example spacing <- c('%-30s', rep('%-13s', 2), '%-15s', '%-3s')
#' @importFrom purrr map2_df
#' @return updated text file
#' @keywords internal
#' @export
#'
#' @examples
#' \dontrun{
#' spacing <- c(rep('%10s', 5))
#' df_to_txt("output", "time.sim", df, spacing)
#' }

df_to_txt <- function(write_path, fname, df, spacing){
  txt <- df %>%
    map2_df(., spacing, ~sprintf(.y, .x)) %>%
    apply(., 1, paste, collapse = ' ')
  write.table(txt, paste0(write_path, "/", fname), append = TRUE, sep = "\t", dec = ".", row.names = FALSE, col.names = FALSE, quote = FALSE)
}

# WGN helpers -----------------------------------------------------------------

#' Function to calculate pcp_skew parameter
#'
#' @param x vector of numbers 
#' @param na.rm logical, if NA should be cleaned
#' @return numeric result
#' @keywords internal
#' @examples
#' \dontrun{
#' my.skew(x)
#' }

my.skew <- function(x, na.rm = FALSE){
  if(na.rm)
    x <- x[!is.na(x)]
  else if (any(is.na(x)))
    return(NA)
  n <- length(x)
  if(n == 0)
    return(NA)
  skew <- (n * sum((x - mean(x))^3)) / ((n-1) * (n-2) * sd(x)^3)
  return(skew)
}

#' Helper for my.pwd function
#'
#' @param x vector of numbers 
#' @return logical, if wet day after dry
#' @keywords internal
#' @examples
#' \dontrun{
#' my.check.pwd(x)
#' }

my.check.pwd <- function(x){
  nwd <- sum(if(x[1] == 0 & x[2] > 0){TRUE} else{FALSE})
  return(nwd)
}

#' Helper for my.pww function
#'
#' @param x vector of numbers 
#' @return logical, if wet day after wet
#' @keywords internal
#' @examples
#' \dontrun{
#' my.check.pww(x)
#' }

my.check.pww <- function(x){
  nww <- sum(if(x[1] > 0 & x[2] > 0){TRUE} else{FALSE})
  return(nww)
}

#' Function to calculate wet_dry parameter
#'
#' @param x vector of numbers 
#' @param na.rm logical, if NA should be cleaned
#' @importFrom zoo rollapply
#' @return numeric result
#' @keywords internal
#' @examples
#' \dontrun{
#' my.pwd(x)
#' }

my.pwd <- function(x, na.rm = FALSE){
  if(na.rm)
    x <- x[!is.na(x)]
  else if (any(is.na(x)))
    return(NA)
  if(sum(x == 0) == 0)
    return(0)
  pwd <- sum(rollapply(data = x, width = 2, my.check.pwd)) / sum(x == 0)
  return(pwd)
}

#' Function to calculate wet_wet parameter
#'
#' @param x vector of numbers 
#' @param na.rm logical, if NA should be cleaned
#' @importFrom zoo rollapply
#' @return numeric result
#' @keywords internal
#' @examples
#' \dontrun{
#' my.pww(x)
#' }

my.pww <- function(x, na.rm = FALSE){
  if(na.rm)
    x <- x[!is.na(x)]
  else if (any(is.na(x)))
    return(NA)
  if(sum(x > 0) == 0)
    return(NA)
  pww <- sum(rollapply(data = x, width = 2, my.check.pww)) / sum(x > 0)
  return(pww)
}

#' Function to calculate pcp_days parameter
#'
#' @param x vector of numbers 
#' @param nyears numeric number of years available for PCP variable
#' @param na.rm logical, if NA should be cleaned
#' @return numeric result
#' @keywords internal
#' @examples
#' \dontrun{
#' my.pcpd(x)
#' }

my.pcpd <- function(x, nyears, na.rm = FALSE){
  if(na.rm)
    x <- x[!is.na(x)]
  else if (any(is.na(x)))
    return(NA)
  if(nyears == 0)
    return(NA)
  pcpd <- sum(x > 0) / nyears
  return(pcpd)
}

#' Function to calculate hhr parameter
#'
#' @param x vector of numbers 
#' @param na.rm logical, if NA should be cleaned
#' @return numeric result
#' @keywords internal
#' @examples
#' \dontrun{
#' my.pcpmhhr(x)
#' }

my.pcpmhhr <- function(x, na.rm = FALSE){ # this is an alternative way to calculate max half-hourly rainfall
  if(na.rm)                               # it disaggregates the maximum daily pcp by multiplying with (30/1440)^0.25
    x <- x[!is.na(x)]                     # perhaps useful if no subdaily pcp data are available
  else if (any(is.na(x)))                 # source: Bernhofer script
    return(NA)  
  pcpmhhr <- max(x)*(30/1440)^0.25
  return(pcpmhhr)
}

# Cleaning data ----------------------------------------------------------------

#' Clean outliers outside specified standard deviations
#'
#' This function cleans outliers from a dataframe based on some standard deviations.
#'
#' @param df A dataframe with columns "Station", "DATE", "Variables", "Values", 
#' "Source". The "Variables" column should contain the names of the variables.
#' @param times_sd (optional) A numeric value representing the multiplication factor for 
#' standard deviation. Values outside mean - sd X times_sd and mean + sd X 
#' times_sd are identified as outliers. Default \code{times_sd = 3}.
#' @return A list of two dataframes. 
#'   *newdf* contains the dataframe cleaned from outliers. 
#'   *dropped* contains the data that was removed from *newdf*.
#' @importFrom dplyr mutate %>% group_by summarise left_join
#' @importFrom lubridate month 
#' @export
#'
#' @examples
#' \dontrun{
#'   # Load calibration data from an Excel file
#'   temp_path <- system.file("extdata", "calibration_data.xlsx", package = "SWATprepR")
#'   cal_data <- load_template(temp_path)
#'   
#'   # Clean outliers from the data
#'   lst <- clean_outliers(cal_data$data)
#'   
#'   # Display data to be removed
#'   print(head(lst$dropped))
#'   
#'   # Update the original data with cleaned data
#'   cal_data$data <- lst$newdf
#' }
#' @keywords cleaning
#' @seealso \code{\link{load_template}}

clean_outliers <- function(df, times_sd = 3){
  ##Calculating monthly min, max values
  ref_values <- df %>% 
    mutate(Month = month(DATE)) %>% 
    group_by(Station, Variables, Month) %>% 
    summarise(mean = mean(Values), sd = sd(Values), .groups = 'drop') %>% 
    mutate(min_value = ifelse(mean - sd * times_sd < 0, 0, mean - sd * times_sd),
           max_value = mean + sd * times_sd)
  ##Identifying outliers and splitting into two dfs
  df <- df %>% 
    mutate(Month = month(DATE)) %>% 
    left_join(ref_values, by = c("Station", "Variables", "Month")) %>% 
    mutate(P = ifelse(Values >= min_value & Values <= max_value, T, F))
  
  return(list(newdf =  df[df$P == T, c("Station", "DATE", "Variables", "Values", "Source")], 
              dropped = df[df$P == F, c("Station", "DATE", "Variables", "Values", "Source")]))
}

#' Clean water quality data from common issues
#'
#' This function cleans water quality data by addressing common issues.
#'
#' @param df A dataframe with water quality data, including columns "Station", 
#' "DATE", "Variables", "Values", "Source".
#' @param zero_to_min (optional) A numeric coefficient to replace zeros by the 
#' minimum variable value multiplied by zero_to_min.
#' Default is \code{zero_to_min = 0.5} .
#' @return A cleaned dataframe.
#' @export
#' @importFrom dplyr mutate left_join distinct filter summarise select group_by
#' @examples
#' \dontrun{
#'   # Load calibration data from an Excel file
#'   temp_path <- system.file("extdata", "calibration_data.xlsx", package = "SWATprepR")
#'   cal_data <- load_template(temp_path)
#'   
#'   # Clean water quality data
#'   cal_data$data <- clean_wq(cal_data$data)
#' }
#' @keywords cleaning
#' @seealso \code{\link{load_template}}

clean_wq <- function(df, zero_to_min = 0.5){
  ##Cleaning common problems
  if(inherits(df$Values, "character")){
    df <- df %>% 
      mutate(Values = gsub(",", ".", Values)) %>% 
      mutate(Values = ifelse(grepl("<", Values), as.numeric(gsub("<", "", Values))/2, Values)) %>%  ##Below LOD/LOQ, leaving half value.
      mutate(Values = ifelse(grepl("^[0-9]", Values), Values, NA)) %>%  ##From here should be starting with number, if not - NA
      mutate(Values = as.numeric(Values)) 
  } else if (!inherits(df$Values, "numeric")){
    stop("'Values' column data type should be 'numeric' or 'character'!!!")
  }
  ##Dropping NAs
  df <- drop_na(df, Values)
  ##Negative to positive
  df[df$Values < 0, c("Values")] <- abs(df[df$Values < 0, c("Values")])
  ##Fixing N and P units
  df[df$Variables == "NH4", c("Variables", "Values")] <- c("N-NH4", df[df$Variables == "NH4", c("Values")] * 0.776490)
  df[df$Variables == "NO3", c("Variables", "Values")] <- c("N-NO3", df[df$Variables == "NO3", c("Values")] * 0.225897)
  df[df$Variables == "NO2", c("Variables", "Values")] <- c("N-NO2", df[df$Variables == "NO2", c("Values")] * 0.304457)
  df[df$Variables == "PO4", c("Variables", "Values")] <- c("P-PO4", df[df$Variables == "PO4", c("Values")] * 0.326138)
  ##Replacing zeros with min values, dropping NAs and duplicates
  df <- df %>%
    left_join(df %>%
                filter(Values > 0) %>%
                group_by(Variables) %>%
                summarise(min_value = min(Values), .groups = 'drop'), by = c("Variables")) %>%
    mutate(Values = ifelse(Values == 0 & !grepl("^Q", Variables), min_value * zero_to_min, Values)) %>%
    select(Station, DATE, Variables, Values, Source) %>%
    filter(!is.na(Values)) %>%
    distinct()
  return(df)
}

#' Replace very low or empty PCP entries with valid data or 0
#'
#' This function replaces deals with suspiciously low, missing PCP entries 
#' in the provided dataframe.
#'
#' @param df_to_correct The dataframe to correct for the PCP variable with 
#' "DATE" and "PCP" columns.
#' @param df_valid (optional) The dataframe with valid data for the PCP variable,
#'  having "DATE" and "PCP" columns. If not provided, the function will use the 
#'  df_to_correct data. It should overlap with df_to_correct data.
#' @param value_to_zero (optional) The numeric value of daily PCP. Only NA values 
#' can be set to 0 when df_valid PCP values are below or equal to value_to_zero 
#' (default is 0.2).
#' @importFrom dplyr left_join mutate case_when filter select
#' @return Updated dataframe 
#'
#' @examples
#' \dontrun{
#' # Get the current date as a POSIXct object
#' today <- as.POSIXct(Sys.Date())
#' # Set the end date as 10 days from the current date
#' end_day <- as.POSIXct(Sys.Date() + 10)
#'
#' # Create a dataframe with a sequence of dates and corresponding PCP values
#' df_to_correct <- data.frame(
#'   DATE = seq.POSIXt(today, end_day, by = "1 day"),  # Create a daily sequence of dates
#'   PCP = c(0.1, NA, 0.3, NA, 0.5, NA, 0.7, NA, 0.9, NA, 1.1)
#' )
#'
#' # Create a dataframe with valid PCP values for the same date range
#' df_valid <- data.frame(
#'   DATE = seq.POSIXt(today, end_day, by = "1 day"),  # Create a daily sequence of dates
#'   PCP = c(0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.2)
#' )
#'
#' # Apply the function to replace missing PCP values with zero
#' add_missing_pcp_zero(df_to_correct, df_valid, 0.3)
#' }

#' @keywords internal

add_missing_pcp_zero <- function(df_to_correct, df_valid = NULL, value_to_zero = 0.2) {
  # Create a dataframe with a sequence of dates
  df <- data.frame(DATE = seq.POSIXt(df_to_correct[[1, "DATE"]], 
                                     df_to_correct[[nrow(df_to_correct), "DATE"]], by = "day"))
  
  # Left join the sequence dataframe with the input dataframe based on the "DATE" column
  df <- left_join(df, df_to_correct, by = "DATE") 
  
  # Replace missing values with zero if df_valid is NULL; otherwise, apply additional logic
  if (is.null(df_valid)) {
    df[is.na(df)] <- 0
  } else {
    df <- df %>% 
      left_join(rename(df_valid, P = 2), by = "DATE") %>%
      mutate(PCP = case_when(is.na(PCP) | PCP <= value_to_zero ~ P,
                             !is.na(PCP) & PCP > value_to_zero ~ PCP)) %>% 
      filter(!is.na(PCP)) %>% 
      select(DATE, PCP)
  }
  
  # Return the updated dataframe
  return(df)
}

# Gaps in weather data ---------------------------------------------------------

#' Find Closest Stations for Meteorological Parameters
#'
#' This function finds the closest stations for specified meteorological parameters.
#'
#' @param meteo_lst A nested list with dataframes. 
#'   Nested structure: \code{meteo_lst -> data -> Station ID -> Parameter -> 
#'   Dataframe (DATE, PARAMETER)}.
#'   Nested \code{meteo_lst -> stations -> Dataframe (ID, Name, Elevation, Source, 
#'   geometry, Long, Lat)}. \cr\cr
#'   meteo_lst can be created using \code{\link{load_template}} function using 
#'   'xlsx' template file or it could to be created with \code{\link{load_swat_weather}}
#'   function loading information from SWAT+ model setup weather files.
#' @param par_fill (optional) A vector of variables to be filled. Default is 
#' \code{par_fill = c("TMP_MAX", "TMP_MIN","PCP", "RELHUM", "WNDSPD", "SLR")}.
#' @importFrom sf st_distance
#' @importFrom dplyr filter %>% 
#' @importFrom purrr map walk walk2 compact
#' @return A data frame with station information and filled meteorological parameters.
#'
#' @examples
#' \dontrun{
#'   # Load weather data from an Excel file
#'   temp_path <- system.file("extdata", "weather_data.xlsx", package = "SWATprepR")
#'   met_lst <- load_template(temp_path, 3035)
#'   
#'   # Fill for missing variables
#'   df <- find_closest(met_lst)
#' }
#' @keywords internal

find_closest <- function(meteo_lst, par_fill = c("TMP_MAX", "TMP_MIN", "PCP", "RELHUM", "WNDSPD", "SLR")) {
  ## Initializing vectors, lists
  df_list <- meteo_lst$data
  stations <- names(df_list)
  av_list <- list()
  
  # Filling available values for each parameter
  walk(par_fill, ~{
    p <- .x
    av_list[[.x]] <<- map(stations, ~{
      if (!is.null(df_list[[.x]][[p]])) .x else NULL
    }) %>% compact %>% unlist
  })
  
  # Creating a data frame to store results
  df <- data.frame(stations = stations); df[par_fill] <- NA
  
  # Filling data frame with available values
  walk2(par_fill, av_list, ~{df[df$stations %in% .y, .x] <<- .y})
  
  # Finding closest stations for missing values
  walk(par_fill, ~{
    sel <- meteo_lst$stations %>% filter(ID %in% as.vector(av_list[[.x]]))
    m <- st_distance(meteo_lst$stations, sel)
    rownames(m) <- meteo_lst$stations$ID
    colnames(m) <- sel$ID
    p <- .x
    stations[!stations %in% av_list[[.x]]] %>%
      walk(~ {
        st_fill <- colnames(m)[which(m[.x, ] == min(m[.x, ]))]
        df[df$station == .x, p] <<- st_fill
      })
  })
  
  return(df)
}


#' Fill missing variables from the closest stations with available data
#'
#' This function fills missing variables by interpolating values from the 
#' closest stations that have data.
#'
#' @param meteo_lst A nested list with dataframes. 
#'   Nested structure: \code{meteo_lst -> data -> Station ID -> Parameter -> 
#'   Dataframe (DATE, PARAMETER)}.
#'   Nested \code{meteo_lst -> stations -> Dataframe (ID, Name, Elevation, Source, 
#'   geometry, Long, Lat)}. \cr\cr
#'   meteo_lst can be created using \code{\link{load_template}} function using 
#'   'xlsx' template file or it could to be created with \code{\link{load_swat_weather}}
#'   function loading information from SWAT+ model setup weather files.
#' @param par_fill (optional) A vector of variables to be filled. Default is 
#' \code{par_fill = c("TMP_MAX", "TMP_MIN","PCP", "RELHUM", "WNDSPD", "SLR")}.
#' @importFrom purrr walk
#' @importFrom dplyr filter %>% 
#' @return A list of dataframes with filled data. Updated list is for meteo_lst$data.
#'
#' @examples
#' \dontrun{
#'   # Load weather data from an Excel file
#'   temp_path <- system.file("extdata", "weather_data.xlsx", package = "SWATprepR")
#'   met_lst <- load_template(temp_path, 3035)
#'   
#'   # Fill for missing variables
#'   met_lst$data <- fill_with_closest(met_lst, c("TMP_MAX", "TMP_MIN"))
#' }
#' @keywords internal

fill_with_closest <- function(meteo_lst, par_fill = c("TMP_MAX", "TMP_MIN","PCP", "RELHUM", "WNDSPD", "SLR")){
  df <- find_closest(meteo_lst, par_fill)
  walk(df$stations, function(x){
    walk(par_fill, function(y){
      meteo_lst$data[[x]][[y]] <<- meteo_lst$data[[df[df$stations == x, y]]][[y]]
    })
  })
  return(meteo_lst)
}

# Short helpers ----------------------------------------------------------------

`%||%` <- function(lhs, rhs) {
  if (is.null(lhs)) rhs else lhs
}

# A helper function for safe NetCDF variable retrieval
rvar_get <- function(nc_file, var_name) {
  tryCatch(
    {
      # Attempt to retrieve the variable
      var_data <- RNetCDF::var.get.nc(nc_file, var_name)
      return(var_data)
    },
    error = function(e) {
      message("Error retrieving variable '", var_name, "': ", e$message)
      return(NA)  # Return NA on error
    }
  )
}