#' Plot goodness of fit (GOF) tables
#'
#' `plot_gof()` plots summary boxplots of one or a list of GOF tables as
#' ggplots.
#'
#'
#' @param gof_tbls A data.frame containing goodness of fit values, or a list of
#'   such tables.
#' @param gofs (optional) A character vector indicating selected GOFs to plot.
#'   Default is `NULL` and all GOFs in the provided `gof_tbls` are plotted
#' @param colors (optional) A character vector to define the fill colors of the
#'   boxes. Must be the same length as the number of tables to plot. Default is
#'   `NULL` and a default color pallette is used.
#' @param n_col (optional) Number of columns of plot panels to plot. Default is
#'   `n_col = 3`
#'
#' @returns A ggplot object with boxplots of GOF values.
#'
#' @importFrom dplyr bind_rows filter mutate select %>%
#' @importFrom purrr map2
#' @importFrom tidyr pivot_longer
#' @importFrom tidyselect any_of
#' @importFrom ggplot2 aes element_blank element_text facet_wrap geom_boxplot
#'   geom_jitter ggplot rel scale_fill_manual theme theme_bw
#'
#' @export
#'
#' @examples
#' \dontrun{
#' library(SWATrunR)
#'
#' # Generate dummy gof table
#' n <- 50
#' gof_cal <- data.frame(run   = id_to_run(1:n, n),
#'                       nse   = runif(n, 0.4, 0.7),
#'                       pbias = runif(n, -25, 0),
#'                       kge   = runif(n, 0.5, 0.8))
#'
#' # Plot single glof table
#' plot_gof(gof_cal)
#'
#' # Plot list of gof tables
#' gof_val <- data.frame(run   = id_to_run(1:n, n),
#'                       nse   = runif(n, 0.2, 0.55),
#'                       pbias = runif(n, -20, 10),
#'                       kge   = runif(n, 0.3, 0.55))
#'
#' gof_tbls <- list(calibration = gof_cal, validation = gof_val)
#'
#' plot_gof(gof_tbls)
#' }
#'
#' @keywords plot
#'
#' @seealso \code{\link{calc_gof}}
#'
plot_gof <- function(gof_tbls, gofs = NULL , colors = NULL, n_col = 3) {
  if(is.data.frame(gof_tbls)) {
    gof_tbls <- gof_tbls %>%
      mutate(., name = '')
  } else if (is.list(gof_tbls)) {
    if(!is.data.frame(gof_tbls[[1]])) {
      stop("'gof_tbls' must be either a table or a list of tables.")
    }
    if(is.null(names(gof_tbls))) {
      names(gof_tbls) <- paste0('tbl_', 1:length(gof_tbls))
    }
    if(length(unique(names(gof_tbls))) != length(gof_tbls)) {
      stop("All tables in 'gof_tbls' must have unique names.")
    }
    gof_tbls <- gof_tbls %>%
      map2(., names(gof_tbls), ~ mutate(.x, name = .y)) %>%
      bind_rows(.)
  }

  gof_tbls <- gof_tbls %>%
    select(-any_of('run')) %>%
    pivot_longer(cols = -name, names_to = "gof", values_to = "value")

  if(!is.null(gofs)){
    gof_tbls <- filter(gof_tbls, gof %in% gofs)
  }

  gof_tbls <- mutate(gof_tbls,
                     name = factor(name, levels = unique(name)),
                     gof  = factor(gof,  levels = unique(gof)))

  if(!is.null(colors)) {
    if(length(colors) < length(unique(gof_tbls$name))) {
      stop("Not enough 'colors' defined to plot 'gof_tbls'.")
    }
    col_pal <- colors
  } else {
    col_pal <- c("#80B1D3", "#FB8072", "#FFED6F", "#8DD3C7", "#BEBADA",
                 "#FDB462", "#FCCDE5", "#D9D9D9", "#BC80BD", "#A65628")
  }

  ggplot(gof_tbls, aes(x = name, y = value, fill = name)) +
    geom_boxplot() +
    geom_jitter(color="black", alpha=0.4) +
    scale_fill_manual(values = col_pal) +
    facet_wrap(.~gof, scales = "free_y", ncol = n_col, strip.position = 'left') +
    theme_bw() +
    theme(axis.title = element_blank(),
          axis.ticks.x = element_blank(),
          axis.text.x = element_text(size = rel(1.2)),
          strip.background = element_blank(),
          strip.text = element_text(size = rel(1)),
          strip.placement = "outside",
          legend.position = 'none')

}

#' Function to plot OAT (One-At-A-Time) analysis results
#'
#' This function generates an interactive dygraph to visualize the results of an OAT analysis,
#' comparing simulated data with observed data if provided.
#'
#' @param sim Object containing simulation data from SWATrunR.
#' @param obs Optional dataframe for observed data with columns 'date' and 'value'. Default is NULL.
#' @param variable Name of the variable for which OAT analysis results are plotted.
#' @param round_values Number of decimal places to round parameter values. Default is 3.
#'
#' @return A dygraph object showing the OAT analysis results.
#'
#' @importFrom xts xts
#' @importFrom dplyr select left_join
#' @importFrom dygraphs dygraph dyOptions dySeries dyRangeSelector dyHighlight dyCSS
#' @importFrom stringr str_replace_all
#' @importFrom purrr map set_names
#' @importFrom tibble as_tibble
#' @importFrom readr parse_number
#' @export
#'
#' @examples
#' \dontrun{
#' plot_oat(sim_oat, obs = obs_data, variable = 'flo_day', round_values = 2)
#' }
#' @seealso \code{\link{plot_timeseries}}, \code{\link{sample_oat}}, \code{\link[SWATrunR:run_swatplus]{https://chrisschuerz.github.io/SWATrunR/}}


plot_oat <- function(sim, obs = NULL, variable, round_values = 3) {
  if(!is.null(obs)) {
    if(!is.Date(obs[[1]])){
      stop("The first column of 'obs' must by of type 'Date'.")
    }
    names(obs) <- c('date', 'obs')
  }

  par_oat <- sim$parameter$values

  parameter <- names(par_oat)[map(names(par_oat), ~length(unique(par_oat[[.]]))) > 1]

  run_name <- paste0('run_',
                     sprintf(paste0('%0',
                                    nchar(as.character(nrow(par_oat))), 'd'),
                             as.numeric(row.names(par_oat))))

  run_exist <- run_name %in% names(sim$simulation[[variable]])
  sim_sel <- sim$simulation[[variable]][, c('date', run_name[run_exist])] %>%
    set_names(c('date', paste0(parameter,':', round(par_oat[as.vector(parse_number(run_name[run_exist])), parameter][[1]], round_values))))

  col_pal <- c("#377EB8", "#4DAF4A", "#984EA3", "#FF7F00", "#FFFF33",
               "#A65628", "#F781BF", "#999999", "#1B9E77", "#D9D9D9")
  col_pal <- col_pal[run_exist]

  if (!is.null(obs)) {
    sim_sel <- left_join(sim_sel, obs, by = 'date')
    col_pal <- c(col_pal, 'black')
  }

  sim_sel_xts <- xts(select(sim_sel, -date), order.by = sim_sel$date)



  dy_oat <- dygraph(sim_sel_xts) %>%
    dyRangeSelector(height = 100, fillColor = 'gray', strokeColor = 'black') %>%
    dyOptions(colors = col_pal) %>%
    dyHighlight(highlightSeriesBackgroundAlpha = 0.6,
                hideOnMouseOut = FALSE) %>%
    dyCSS(textConnection("
     .dygraph-legend > span.highlight { display: inline; background-color: #B0B0B0;}
  "))

  if (!is.null(obs)) {
    dy_oat <- dySeries(dy_oat, 'obs', drawPoints = TRUE,
                       pointSize = 2, strokeWidth = 0.75)
  }

  return(dy_oat)
}

#' Plot Parameter Identifiability
#'
#' This function creates a plot to visualize the identifiability of parameters
#' based on objective functions.
#'
#' @param parameters A vector of parameter names.
#' @param objectives A list of objective functions, each represented as a numeric vector.
#' @param run_fraction (optional) A numeric value representing the fraction of
#' runs to consider for threshold calculation. Default \code{run_fraction = NULL},
#' which defines this parameter according method provided in the function.
#'
#' @return A ggplot object visualizing the identifiability of parameters.
#'
#' @importFrom ggplot2 scale_y_continuous scale_fill_gradientn geom_rect facet_wrap labs theme_bw theme unit element_blank
#' @importFrom dplyr mutate %>%
#' @importFrom purrr map_dbl map2_df
#' @importFrom scales rescale
#' @importFrom tibble tibble
#'
#' @export


plot_parameter_identifiability <- function(parameters, objectives, run_fraction = NULL) {
  objectives <- select(objectives, - any_of('run'))

  if(is.null(run_fraction)) {
    nb_run <- dim(parameters)[1]
    if(nb_run >= 5000){
      run_fraction <- 0.15 - ((nb_run - 5000)/100000)
    } else if(nb_run >= 1000){
      run_fraction <- 0.225 - ((nb_run - 1000)/40000)
    } else if (nb_run >= 100){
      run_fraction <- 0.5 - ((nb_run - 100)/3000)
    } else {
      run_fraction <- 0.5
    }
    message(paste0("The number of runs is ", nb_run, ". The 'run_fraction' parameter is set to ", run_fraction))
  }
  thresholds <- map_dbl(objectives, ~ quantile(.x, 1 - run_fraction))
  plot_tbl <- map2(objectives, thresholds,
                   ~ calc_segment_diff(parameters, .x, .y)) %>%
    map2_df(., 1:length(.), ~ mutate(.x, id = .y))

  lbls <- tibble(obj = names(objectives), y = 1:ncol(objectives))

  col_vals <- c(seq(-100, -25, length.out = 4), seq(0, max(100, max(plot_tbl$fill_segment)), length.out = 5))
  col_pal <- c("#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#F7F7F7",
               "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC")
  # col_pal <- c(col_pal_full[1], col_pal_full[(6 - n_neg):4], col_pal_full[5:9])
  ggplot(plot_tbl) +
    geom_rect(aes(xmin = xmin, xmax = xmax, ymin = id - 0.5, ymax = id + 0.5, fill = fill_segment)) +
    facet_wrap(.~parameter, scales = 'free_x') +
    scale_y_continuous(breaks = lbls$y, labels = lbls$obj) +
    scale_fill_gradientn(colors = col_pal, values = rescale(col_vals),
                         limits = c(-100, max(100, max(plot_tbl$fill_segment)))) +
    labs(fill = 'Deviation to uniform distribution (%)') +
    theme_bw() +
    theme(legend.position = 'bottom',
          legend.key.width = unit(2, 'cm'),
          panel.grid.minor.y = element_blank())
}


#' Plot PHU, yield, and biomass over days to maturity
#'
#' This function generates boxplots to visualize Plant Heat Units (PHU)
#' fractions, yields, and biomass over changes in days to maturity.
#'
#' @param sim_result The simulation results containing PHU, yield, and biomass
#'   data.
#' @param yield_obs (optional) A data frame with observed minimum, maximum, and mean yield
#'   values for each crop. Default is \code{NULL}. No data is provided. If provided,
#'   the data frame should contain the following columns: \code{plant_name},
#'   \code{yield_min}, \code{yield_max}, and \code{yield_mean}.
#' @param bar_width (optional) Value from 0 to 1 controls the width of the box
#' in the boxplot. Default \code{bar_width = 0.5}.
#'
#' @returns A combined ggplot object showing boxplots for PHU fractions, yields,
#'   and biomass.
#'
#' @importFrom ggplot2 ggplot geom_boxplot geom_hline facet_grid
#'   scale_x_discrete scale_fill_manual coord_cartesian labs theme_bw theme
#'   element_blank aes element_text vars
#' @importFrom dplyr filter select arrange join_by left_join mutate rename %>%
#' @importFrom gridExtra grid.arrange
#' @importFrom lubridate year
#' @importFrom stringr str_detect str_remove_all
#' @importFrom tibble tibble
#' @importFrom tidyr pivot_longer
#' @importFrom tidyselect starts_with
#' @import ggplot2
#'
#' @export
#'
#' @keywords plot

plot_phu_yld_bms <- function(sim_result, yield_obs = NULL, bar_width = 0.5) {
  # mgtout also prints the skipped years, therefore limit to the years after the
  # skipped time period
  start_year <- year(sim_result$run_info$simulation_period$start_date)
  end_year   <- year(sim_result$run_info$simulation_period$end_date)
  if(!is.na(sim_result$run_info$simulation_period$years_skip)) {
    start_year <- year(sim_result$run_info$simulation_period$start_date)
    start_year <- start_year + sim_result$run_info$simulation_period$years_skip
  } else {
    start_year <- year(sim_result$run_info$simulation_period$start_date_print)
  }

  sim_years <- start_year:end_year

  col_pal <- c("#7570B3", "#8DD3C7", "#666666", "#FFFFB3", "#D95F02", "#66A61E",
               "#BEBADA", "#FB8072", "#80B1D3", "#E7298A", "#FDB462", "#B3DE69",
               "#A6761D", "#FCCDE5", "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F",
               "#1B9E77", "#E6AB02")

  if('days_mat' %in% sim_result$parameter$definition$parameter) {
    par_name <- sim_result$parameter$definition %>%
      filter(str_detect(par_name, 'days_mat')) %>%
      select(par_name, name) %>%
      mutate(name = str_remove_all(name, "==|'|[:space:]+"))

    par_val <- sim_result$parameter$values %>%
      select(par_name$par_name) %>%
      set_names(par_name$name) %>%
      mutate(name = names(sim_result$simulation$phu)[-(1:3)]) %>%
      pivot_longer(., cols = -name, names_to = 'plant_name', values_to = 'phu')

  } else if(ncol(sim_result$simulation$phu) == 4) {
    par_name <- tibble(par_name = unique(sim_result$simulation$phu$plant_name),
                       name = par_name)

    par_val <- tibble(name = 'run_1',
                      plant_name = unique(sim_result$simulation$phu$plant_name),
                      phu = 0)
  }

  if(is.null(yield_obs)) {
    yield_obs <- tibble(plant_name = character())
  }

  plotted_crops <- unique(sim_result$simulation$phu$plant_name[
    sim_result$simulation$phu$year %in% sim_years])
  missing_crops <- setdiff(yield_obs$plant_name, plotted_crops)
  if (length(missing_crops)) {
    warning("No simulated harvest records in the plotted period for: ",
            paste(missing_crops, collapse = ", "), call. = FALSE)
  }
  # Observation-only crops would otherwise add unlabelled facets to just the
  # yield row and misalign it with the PHU and biomass crop headings.
  par_name <- par_name[par_name$name %in% plotted_crops, , drop = FALSE]
  yield_obs <- left_join(par_name, yield_obs,
                         by = join_by(name == plant_name)) %>%
    rename(plant_name = name)

  if(!'yield_min' %in% names(yield_obs)) {
    yield_obs$yield_min <- NA_real_
  }
  if(!'yield_max' %in% names(yield_obs)) {
    yield_obs$yield_max <- NA_real_
  }
  if(!'yield_mean' %in% names(yield_obs)) {
    yield_obs$yield_mean <- NA_real_
  }

  # Prepare the simulations of PHU fractions for plotting
  phu <- sim_result$simulation$phu %>%
    filter(year %in% sim_years) %>%
    select(-year, -hru) %>%
    pivot_longer(., cols = - plant_name) %>%
    left_join(., par_val, by = join_by(plant_name, name)) %>%
    mutate(phu = factor(phu))

  #Plot PHU fractions per crop over the days_mat changes
  gg_phu <- ggplot(data = phu) +
    geom_boxplot(aes(x = phu, y = value, fill = name), width = bar_width) +
    geom_hline(yintercept = 1, linetype = 'dashed') +
    geom_hline(yintercept = 1.25, linetype = 'dashed') +
    facet_grid(cols = vars(plant_name), scales = 'free_x') +
    scale_fill_manual(values = col_pal) +
    coord_cartesian(ylim = c(0, 2)) +
    labs(y = 'PHU fraction at harves/kill') +
    theme_bw() +
    theme(axis.title.x = element_blank(),
          axis.text.x = element_blank(),
          legend.position = 'none')

  # Prepare the simulations of yields for plotting
  yld <- sim_result$simulation$yld %>%
    filter(year %in% sim_years) %>%
    select(-year, -hru) %>%
    pivot_longer(., cols = - plant_name) %>%
    mutate(value = value/1000) %>%
    left_join(., par_val, by = join_by(plant_name, name)) %>%
    mutate(phu = factor(phu))

  #Plot yields per crop over the days_mat changes
  gg_yld <- ggplot(data = yld) +
    geom_boxplot(aes(x = phu, y = value, fill = name), width = bar_width) +
    facet_grid(cols = vars(plant_name), scales = 'free_x') +
    scale_fill_manual(values = col_pal) +
    labs(y = 'Yield (t/ha)', x = 'days_mat absval change') +
    theme_bw() +
    theme(axis.title.x = element_blank(),
          axis.text.x = element_blank(),
          strip.background = element_blank(),
          strip.text = element_blank(),
          legend.position = 'none') +
    geom_hline(data = yield_obs, aes(yintercept = yield_mean), color = "tomato3",
               linetype = "solid", linewidth = 1) +
    geom_hline(data = yield_obs, aes(yintercept = yield_min), color = "tomato1",
               linetype = "dashed") +
    geom_hline(data = yield_obs, aes(yintercept = yield_max), color = "tomato1",
               linetype = "dashed") +
    labs(caption = "Red lines represent observed values.")

  # Prepare the simulations of yields for plotting
  bms <- sim_result$simulation$bms %>%
    filter(year %in% sim_years) %>%
    select(-year, -hru) %>%
    pivot_longer(., cols = - plant_name) %>%
    mutate(value = value/1000) %>%
    left_join(., par_val, by = join_by(plant_name, name)) %>%
    mutate(phu = factor(phu))

  #Plot yields per crop over the days_mat changes
  gg_bms <- ggplot(data = bms) +
    geom_boxplot(aes(x = phu, y = value, fill = name), width = bar_width) +
    facet_grid(cols = vars(plant_name), scales = 'free_x') +
    scale_fill_manual(values = col_pal) +
    labs(y = 'Biomass (t/ha)') +
    theme_bw()+
    theme(strip.background = element_blank(),
          strip.text = element_blank(),
          legend.position = 'none')

  if(length(unique(bms$name)) != 1){
    gg_bms <- gg_bms +
      labs(x = 'days_mat') +
      theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
  } else {
    gg_bms <- gg_bms +
      theme(axis.title.x = element_blank(),
            axis.text.x = element_blank())
  }

  # Put the PHU plot and the yield plot together
  grid.arrange(gg_phu, gg_yld, gg_bms, ncol = 1)
}

#' Plot Dotty Yields
#'
#' This function creates dotty plots for simulated yields, comparing them with
#' observed yields (if available).
#'
#' @param sim_result The simulation results containing yield data.
#' @param yield_obs (optional) Data.frame with observed min, max, and mean yield
#'   values for each crop. Default \code{yield = NULL}.
#'
#' @returns A combined ggplot object showing dottty plots for 4 parameters.
#'
#' @importFrom tidyr pivot_longer
#' @importFrom stringr str_remove
#' @importFrom purrr map
#' @importFrom dplyr %>% mutate arrange left_join rename any_of
#' @importFrom lubridate year
#' @export
#' @examples
#' \dontrun{
#' plot_phu_yld_bms(ylds_phu_dmat, dmat_chg, yield_mean, yield_min, yield_max)
#' }
#' @keywords plot
#'
plot_dotty_yields <- function(sim_result, yield_obs = NULL) {
  ##Years to filter
  start_year <- year(sim_result$run_info$simulation_period$start_date)+
    sim_result$run_info$simulation_period$years_skip
  end_year <- year(sim_result$run_info$simulation_period$end_date)

  par <- sim_result$parameter$values %>%
    mutate(run = 1:nrow(.))
  # Prepare yields from simulations in data frame for plotting
  yld <- sim_result$simulation$yld %>%
    filter(year %in% start_year:end_year) %>%
    select(-year, -hru) %>%
    pivot_longer(., cols =  starts_with('run'), names_to = 'run') %>%
    mutate(value = value/1000,
           run = as.numeric(str_remove(run, 'run_'))) %>%
    arrange(plant_name) %>%
    left_join(., par, by = c('run')) %>%
    select(-any_of(c("run", "date", "name"))) %>%
    pivot_longer(!c(plant_name, value), names_to = "parameter",
                 values_to = "values") %>%
    rename(yield = value)

  dotty_fig(yld, yield_obs)
}

#' Make a dotty plot
#'
#' @param sim_yield a dataframe with yield data
#' @param yld_obs (optional) The yield values for each crop with columns:
#' plant_name, yield_min, yield_max, yield_mean. Default \code{yld_obs = NULL}.
#' @importFrom tibble enframe
#' @importFrom dplyr mutate left_join filter group_by summarise
#' @importFrom ggplot2 ggplot geom_pointrange geom_smooth theme element_text
#'   element_blank labs geom_hline facet_grid theme_bw
#' @importFrom stats quantile
#' @return ggplot object for dotty plot
#' @keywords internal
#' @examples
#' \dontrun{
#' dotty_fig(sim_yield)
#' }
#' @keywords plot
#'
dotty_fig <- function(sim_yield, yld_obs = NULL){
  df_rng <- sim_yield %>%
    group_by(plant_name, parameter, values) %>%
    summarise(yld_50  = quantile(yield, probs = 0.5),
              yld_25 = quantile(yield, probs = 0.25),
              yld_75 = quantile(yield, probs = 0.75), .groups = 'drop')

  ggplot()+
    geom_pointrange(data = df_rng, aes(x = values, y = yld_50,
                                       ymin = yld_25, ymax = yld_75),
                    shape = 18) +
    geom_smooth(data = df_rng, aes(x = values, y = yld_50),
                method = 'glm', formula = 'y ~ x') +
    geom_hline(data = yld_obs, aes(yintercept = yield_mean), color = "tomato3",
               linetype = "solid", linewidth = 0.75) +
    geom_hline(data = yld_obs, aes(yintercept = yield_min), color = "tomato1",
               linetype = "twodash") +
    geom_hline(data = yld_obs, aes(yintercept = yield_max), color = "tomato1",
               linetype = "twodash") +
    facet_grid(plant_name~parameter, scales = "free")+
    labs(x = "Value change", y = "Yields (t/ha)",
         caption = "Red lines represent observed values") +
    theme_bw()
}

#' Plot Dotty
#'
#' This function creates a dotty plot to visualize the relationship between
#' parameter values and performance results.
#'
#' @param par A data frame of model parameter values for each simulation.
#' @param var The model performance result vector or list of vectors to be
#' plotted against parameter values.
#' @param y_label (optional) Labels for the y-axis, either a single label or a vector
#' corresponding to each variable if `var` is a list. Default \code{y_label = 'y'}.
#' @param n_col (optional) Number of columns in the facet grid. Default \code{n_col = 3}.
#' @param y_lim (optional) Limits for the y-axis. Default \code{y_lim = NULL}.
#' @param y_inter (optional) Y-axis intercept value. Default \code{y_inter = NULL}.
#' @param trend (optional) Logical, indicating whether to add a trend line.
#' Default is \code{trend = FALSE}.
#' @param run_ids (optional) A numeric vector of run IDs to be highlighted in the plot.
#' Default is \code{run_ids = NULL}.
#' @param low_up (optional) Logical, TRUE if whole possible parameter range should be used
#' for x axis. Default is \code{low_up = FALSE}.
#' @importFrom dplyr %>% select filter left_join rename bind_rows
#' @importFrom ggplot2 ggplot geom_point facet_wrap theme_bw theme element_text
#' scale_color_manual geom_blank geom_smooth geom_hline ylim
#' @importFrom tidyr pivot_longer
#' @importFrom purrr reduce modify2
#' @return A ggplot object representing the dotty plot.
#' @export
#'
#' @examples
#' \dontrun{
#' # plot_dotty(my_data, 'performance', y_label = 'y_label')
#' }
#' @keywords plot

plot_dotty <- function(par, var, y_label = 'y', n_col = 3, y_lim = NULL,
                       y_inter = NULL, trend = FALSE, run_ids = NULL,
                       low_up = FALSE) {
  # Define color palette
  col_pal <- c("grey15", "coral1", "orange4", "slateblue", "deeppink",
               "forestgreen", "gold2", "tomato", "tomato4", "steelblue3", "blue",
               "darkmagenta")
  # Check if 'var' is a list and handle accordingly
  if(is.list(var)){
    if(length(var) != length(y_label)){
      stop('var and y_label should have the same number of inputs')
    }
    # Modify the data based on the list input
    dotty_tbl <- modify2(var, y_label, function(.x, .y){par %>%
        mutate(var = .x) %>%
        pivot_longer(., cols = -var, names_to = 'parameter') %>%
        mutate(y_label = as.factor(.y))}) %>%
      reduce(., bind_rows)
  } else {
    # If 'var' is not a list, handle it normally
    dotty_tbl <- par %>%
      mutate(var = var) %>%
      pivot_longer(., cols = -var, names_to = 'parameter')
  }

  # Create the base ggplot object
  gg <- ggplot(data = dotty_tbl, aes(x = value, y = var, group= y_label, colour = y_label)) +
    geom_point(alpha = ifelse(is.null(trend), 1, 0.3)) +
    scale_color_manual(values = col_pal) +
    facet_wrap(.~parameter, ncol = n_col, scales = "free_x") +
    theme_bw()

  # Add points for specific run_ids if provided
  if(!is.null(run_ids)){
    if(is.numeric(run_ids)){
      if(all(run_ids-floor(run_ids)==0)){
        if(is.list(var)){
          dotty_tbl_ids <- modify2(var, y_label, function(.x, .y){par[run_ids,] %>%
              mutate(var = .x[run_ids]) %>%
              pivot_longer(., cols = -var, names_to = 'parameter') %>%
              mutate(y_label = as.factor(.y))}) %>%
            reduce(., bind_rows)
          gg <- gg + geom_point(data = dotty_tbl_ids, size = 3)
        } else {
          dotty_tbl_ids <- par[run_ids,] %>%
            mutate(var = var[run_ids]) %>%
            pivot_longer(., cols = -var, names_to = 'parameter')
          gg <- gg + geom_point(data = dotty_tbl_ids, color = 'red', size = 2)
        }
      } else {
        stop('run_ids should be integer values!!!')
      }
    } else {
      stop('run_ids should be numeric value or numeric vector of values!!!')
    }
  }

  # Add lower and upper bounds if provided
  if(low_up){
    low_up <- read_tbl(paste0(model_path, '/cal_parms.cal'), n_skip = 2) %>%
      rename(parameter = name) %>%
      filter(parameter %in% dotty_tbl$parameter) %>%
      select(parameter, abs_min, abs_max) %>%
      pivot_longer(., cols = -parameter, names_to = 'par', values_to = 'value') %>%
      select(parameter, value)

    # Add var value
    if(is.list(var)){
      low_up$var <- mean(var[[1]])
      low_up$y_label <- y_label[1]
    } else {
      low_up$var <- mean(var)
    }

    # Add dummy data to the plot
    gg <- gg + geom_blank(data=low_up)
  }

  # Customize the plot based on the number of y labels
  if (length(y_label)>1) {
    gg <- gg + labs(x = 'Change of parameter value', y = "Performance results",  color = "Variables")
  } else {
    gg <- gg +
      theme(legend.position="none")+
      labs(x = 'Change of parameter value', y = y_label)
  }

  # Add trend line if specified
  if(trend){
    gg <- gg + geom_smooth(method = "lm", se = FALSE)
  }

  # Set y-axis limits if provided
  if (!is.null(y_lim)) {
    gg <- gg + ylim(y_lim)
  }

  # Add y-axis intercept line if provided
  if (!is.null(y_inter)) {
    gg <- gg + geom_hline(yintercept = y_inter, lty = 2)
  }

  # Return the ggplot object
  return(gg)
}

#' Plot esco (and epco) to identify appropriate parameter ranges.
#'
#' Dependent on whether esco (and epco) were used in the calibration runs,
#' `plot_esco_epco()` plots the simulatated water yield ratios over the
#' parameter ranges to support the manual selection of parameter values/ranges.
#'
#' @param sim The simulation results water balance data. Including:
#'   \describe{
#'     \item{precip}{Variable out of 'basin_wb_aa' output file.}
#'     \item{surq_cha}{Variable out of 'basin_wb_aa' output file.}
#'     \item{surq_res}{Variable out of 'basin_wb_aa' output file.}
#'     \item{latq_cha}{Variable out of 'basin_wb_aa' output file.}
#'     \item{latq_res}{Variable out of 'basin_wb_aa' output file.}
#'     \item{qtile}{Variable out of 'basin_wb_aa' output file.}
#'     \item{flo}{Variable out of ''basin_aqu_aa' output file.}
#'   }
#' @param wyr_target A numeric value representing the target water yield ratio.
#' @param rel_wyr_limit A numeric value specifying the relative range for
#'   acceptable error.
#' @param extend_axis Logical, whether to extend the axis for better visualization.
#' Active only when both esco and epco are used. Default is \code{extend_axis = FALSE}.
#'
#' @importFrom ggplot2 ggplot geom_line geom_vline geom_text
#' @importFrom stringr str_extract_all
#'
#' @return A ggplot object.
#' @export
#'
plot_esco_epco <- function(sim, wyr_target, rel_wyr_limit = 0.05, extend_axis = FALSE) {
  ## Calculate the water yield ratio
  wyr_sim <- calc_wyr(sim)

  # Plot option for alternative A with only esco.
  if(!'epco' %in% sim$parameter$definition$parameter) {
    ## Get the esco parameter range and and the parameter value
    esco_rng <- find_par_range(sim$parameter$values$esco, wyr_sim,
                               wyr_target, rel_wyr_limit)
    ## Create the ggplot object
    ggplot() +
      geom_line(aes(x = esco_rng$x, y = esco_rng$y)) +
      geom_hline(yintercept = wyr_target, color = 'tomato3') +
      geom_hline(yintercept = (1 + rel_wyr_limit) * wyr_target,
                 color = 'tomato3', linetype = 'dashed') +
      geom_hline(yintercept = (1 - rel_wyr_limit) * wyr_target,
                 color = 'tomato3', linetype = 'dashed') +
      geom_vline(xintercept = esco_rng$par_val, color = 'tomato3') +
      geom_vline(xintercept = esco_rng$par_rng[1], color = 'tomato3', linetype = 'dashed') +
      geom_vline(xintercept = esco_rng$par_rng[2], color = 'tomato3', linetype = 'dashed') +
      geom_text(aes(x = c(esco_rng$par_val, esco_rng$par_rng[1], esco_rng$par_rng[2]),
                    y = rep(wyr_target, 3),
                    label = round(c(esco_rng$par_val, esco_rng$par_rng[1],
                                    esco_rng$par_rng[2]), 2)),
                vjust = - 0.5, hjust = -0.25) +
      labs(x = 'esco', y = 'Water yield ratio') +
      theme_bw()
  } else if (all (c('esco', 'epco') %in% sim$parameter$definition$parameter)) {
    # ## Plot the results
    wyr_xyz <- tryCatch({
      # Try the first approach
      sim$parameter$values %>%
        bind_cols(wyr = unlist(wyr_sim))
    }, error = function(e) {
      # On error, fall back to this
      message("Some simulations were unsuccessful, so you may see some blank spots in the figure.")
      suc_sim_ix <- as.numeric(str_extract_all(names(sim$simulation[[1]]), "\\d+"))
      sim$parameter$values[suc_sim_ix, ] %>%
        bind_cols(wyr = unlist(wyr_sim))
    })
    ## Check for simulation results and target alignment
    breaks_limit <- wyr_target * c(1 - rel_wyr_limit, 1 + rel_wyr_limit)
    target_in_range <- wyr_target >= min(wyr_xyz$wyr) &&
      wyr_target <= max(wyr_xyz$wyr)
    limit_in_range <- all(breaks_limit >= min(wyr_xyz$wyr)) &&
      all(breaks_limit <= max(wyr_xyz$wyr))

    ## Extend the axis if required (only for esco + epco) for better visualization
    if(extend_axis){
      grid <- expand.grid(
        esco = seq(0, 1, length.out = length(unique(wyr_xyz$esco))),
        epco = seq(0, 1, length.out = length(unique(wyr_xyz$epco)))
      )

      esco_vals <- sort(unique(wyr_xyz$esco))
      epco_vals <- sort(unique(wyr_xyz$epco))

      nearest <- function(x, vals) {
        vals[which.min(abs(vals - x))]
      }

      grid$esco_n <- vapply(grid$esco, nearest, numeric(1), esco_vals)
      grid$epco_n <- vapply(grid$epco, nearest, numeric(1), epco_vals)

      wyr_xyz <- left_join(grid, wyr_xyz, by = c("esco_n" = "esco", "epco_n" = "epco"))
    }
    ## Ensamble the figure
    p <- ggplot(wyr_xyz) +
      geom_contour_filled(aes(x = esco, y = epco, z = wyr)) +
      labs(fill = 'wyr simulated', color = NULL) +
      scale_color_manual(values = c('black', 'red')) +
      scale_x_continuous(expand = c(0,0)) +
      scale_y_continuous(expand = c(0,0)) +
      theme_bw()

    if(target_in_range){
      p <- p + geom_contour(aes(x = esco, y = epco, z = wyr, col = 'target wyr'),
                            breaks = wyr_target, linewidth = 1)
    } else {
      message("The target water yield ratio is not within the range of the simulation results. Therefore, it will nots be displayed on the figure.")
    }
    if(limit_in_range){
      p <- p + geom_contour_filled(aes(x = esco, y = epco, z = wyr),
                                   breaks = c(wyr_target* (1 - rel_wyr_limit),
                                              wyr_target* (1 + rel_wyr_limit)),
                                   fill = 'grey50',
                                   alpha = 0.5) +
        geom_contour(aes(x = esco, y = epco, z = wyr, col = 'wyr +/- limit'),
                     breaks = c(wyr_target* (1 - rel_wyr_limit),
                                wyr_target* (1 + rel_wyr_limit)))
    } else {
      message("The target water yield confidence interval lies partially or entirely outside the simulation results. Therefore, it will not be displayed on the figure.")
    }
    return(p)
  } else {
    stop("Either only 'esco' or both 'esco' and 'epco' must be varied for plotting.")
  }
}

#' View interactive time series of simulation results and observations
#'
#' This function plots interactive time series comparing simulated data with observed data.
#'
#' @param sim Data frame with one date column and one or many columns with
#'   values of the simulated variable.
#' @param obs (optional) Data frame with one date and one value column.
#'   Default `obs = NULL`, only simulations are plotted.
#' @param run_ids (optional) Integer vector of run IDs to plot.
#' Default `run_ids = NULL` requires input of run_sel.
#' @param run_sel (optional) Integer vector of run IDs to emphasize in the plot.
#'  Default `run_sel = NULL` requires input of run_ids.
#' @param plot_bands (optional) Logical. If TRUE, includes lower and upper bands of results.
#' Default `plot_bands = TRUE`.
#' @param period (optional) Character defining the time step for aggregation. Options include "day", "week",
#' "month", "year", etc. Use "average monthly" for multi-annual monthly values.
#' Default \code{period = NULL} provides no aggregation. See [lubridate::floor_date](https://www.rdocumentation.org/packages/lubridate/versions/1.3.3/topics/floor_date) for details.
#' @param fn_summarize Function to summarize time intervals. Default \code{fn_summarize ="mean"}, other examples are "median", "sum".
#' See [dplyr::summarise](https://dplyr.tidyverse.org/reference/summarise.html) for details.
#' @param x_label (optional) Character for x axis label. Default \code{x_label = "Date"}.
#' @param y_label (optional) Character for y axis label. Default \code{y_label = "Discharge (m³/s)"}.
#'
#' @return Interactive plot of simulated and observed data.
#' @export
#'
#' @importFrom dplyr mutate group_by summarize_all select left_join bind_cols
#' @importFrom tibble add_column
#' @importFrom xts xts
#' @importFrom dygraphs dygraph dyRangeSelector dySeries dyHighlight
#' @importFrom lubridate is.Date month floor_date
#' @examples
#' \dontrun{
#' view_timeseries(sim_flow, obs = obs, run_ids = run_sel_ids, run_sel = c(95),
#' plot_bands = TRUE, period = "average monthly")
#' }
#' @keywords plot

view_timeseries <- function(sim, obs = NULL, run_ids = NULL, run_sel = NULL, plot_bands = TRUE,
                            period = NULL, fn_summarize = 'mean',
                            x_label = 'Date', y_label = "Discharge (m<sup>3</sup> s<sup>-1</sup>)") {

  # Change the time step to the period of interest.
  if(!is.null(period)) {
    if(period == "average monthly"){
      sim <- mutate(sim, date = month(date)) %>%
        group_by(date) %>%
        summarize_all(get(fn_summarize))
      obs <- mutate(obs, date = month(date)) %>%
        group_by(date) %>%
        summarize_all(get(fn_summarize))
    } else {
      sim <- mutate(sim, date = floor_date(date , period)) %>%
        group_by(date) %>%
        summarize_all(get(fn_summarize))
      obs <- mutate(obs, date = floor_date(date , period)) %>%
        group_by(date) %>%
        summarize_all(get(fn_summarize))
    }
  }


  if(is.null(run_ids) & is.null(run_sel)) {
    stop("At least one of 'run_ids' or 'run_sel' must be provided.")
  }
  if(!is.Date(sim[[1]])){
    if(!is.null(period) && period != "average monthly"){
      stop("The first column of 'sim' must by of type 'Date'.")
    }
  }

  dy_tbl <- select(sim, date)

  if(!is.null(obs)) {
    if(!is.Date(obs[[1]])){
      if(!is.null(period) && period != "average monthly"){
        stop("The first column of 'obs' must by of type 'Date'.")
      }
    }
    names(obs) <- c('date', 'obs')
    dy_tbl <- left_join(dy_tbl, obs, by = 'date')
  }

  nchar_run <- nchar(names(sim)[2]) - 4

  if(!is.null(run_sel)) {
    run_sel <- paste0('run_', sprintf(paste0('%0', nchar_run, 'd'), as.numeric(run_sel)))
    dy_tbl <- add_column(dy_tbl, sim_sel = sim[, run_sel])
  }

  if(!is.null(run_ids)) {
    run_ids <- paste0('run_', sprintf(paste0('%0', nchar_run, 'd'), as.numeric(run_ids)))
    sim_ids <- sim[, run_ids]
    if(plot_bands) {
      sim_upr <- apply(sim_ids, 1, max)
      sim_lwr <- apply(sim_ids, 1, min)
      dy_tbl <- add_column(dy_tbl, upr   = sim_upr, lwr   = sim_lwr,
                           upr_l = sim_upr, lwr_l = sim_lwr)
    } else {
      dy_tbl <- bind_cols(dy_tbl, sim_ids)
    }
  }

  if (is.null(period) || period != "average monthly") {
    dy_xts <- xts(dy_tbl[,-1], order.by = dy_tbl[,1][[1]])
  } else {
    dy_xts <- xts(dy_tbl[,-1], order.by = seq(as.Date("00-01-01"), by = "month", length.out = 12))
  }

  dy_plt <- dy_xts %>%
    dygraph(., xlab = x_label, ylab = y_label) %>%
    dyRangeSelector(height = 30)

  if(!is.null(obs)) {
    dy_plt <- dy_plt %>%
      dySeries('obs', color = 'black', drawPoints = TRUE,
               pointSize = 2, strokeWidth = 0.75)
  }

  if(plot_bands) {
    if(!is.null(run_ids) & !is.null(run_sel)) {
      dy_plt <- dy_plt %>%
        dySeries(c("lwr", "sim_sel", "upr"), label = "sim_sel",
                 color =  "#A50F15", strokeWidth = 1.2,
                 drawPoints = TRUE, pointSize = 2) %>%
        dySeries("lwr_l", label = "lower", color =  "#CB181D",
                 strokePattern = 'dashed') %>%
        dySeries("upr_l", label = "upper", color =  "#CB181D",
                 strokePattern = 'dashed')
    } else if (is.null(run_ids)) {
      dy_plt <- dy_plt %>%
        dySeries("sim_sel", label = "sim_sel",
                 color =  "#A50F15", strokeWidth = 1.2,
                 drawPoints = TRUE, pointSize = 2)
    } else {
      dy_plt <- dy_plt %>%
        dySeries(c("lwr", "upr_l", "upr"), label = "upper",
                 color =  "#CB181D", strokePattern = 'dashed') %>%
        dySeries("lwr_l", label = "lower", color =  "#CB181D",
                 strokePattern = 'dashed')
    }
  } else {
    col_pal <- c("#377EB8", "#4DAF4A", "#984EA3", "#FF7F00", "#FFFF33",
                 "#A65628", "#F781BF", "#999999", "#1B9E77", "#D9D9D9")
    if(!is.null(run_ids)) {
      for(i in 1:length(run_ids)) {
        dy_plt <- dy_plt %>%
          dySeries(run_ids[i], label = run_ids[i],
                   color =  col_pal[i], strokeWidth = 1)
      }
      dy_plt <- dy_plt %>%
        dyHighlight(highlightSeriesBackgroundAlpha = 0.6,
                    hideOnMouseOut = TRUE)
    }
    if (!is.null(run_sel)) {
      dy_plt <- dy_plt %>%
        dySeries("sim_sel", label = "sim_sel",
                 color =  "#A50F15", strokeWidth = 1.2,
                 drawPoints = TRUE, pointSize = 2)
    }
  }

  return(dy_plt)
}


#' Plot time series of simulation results and observations
#'
#' `plot_timeseries()` plots a time series comparing simulated data with observed data.
#'
#' @param sim Data frame with one date column and one or many columns with
#'   values of the simulated variable.
#' @param obs (optional) Data frame with one date and one value column.
#'   Default `obs = NULL`, only simulations are plotted.
#' @param run_sel (optional) Integer value or name of simulation run which
#'   should be plotted as 'selected' run. Default `run_sel = NULL` no run
#'   is plotted as 'selected' run. In this case `run_ids` must be selected for
#'   plotting.
#' @param run_ids (optional) Integer vector or character vector of run IDs
#'   or run names to plot. Default `run_ids = NULL`. In this case only the
#'   'seleced' simulation run from `run_sel` is plotted. If `plot_bands = TRUE`
#'   the selected `run_ids` are used to calculate and plot the upper and lower
#'   boundaries of the plotted band. If `plot_bands = FALSE` a maximum number of
#'   10 `run_ids` can be selected for plotting.
#' @param plot_bands (optional) If TRUE, upper and lower boundary values are
#'   calculated from the selected `run_ids` and a band is plotted for them. If
#'   FALSE the individual selected runs from `run_ids` are plotted.
#'   Default `plot_bands = TRUE`.
#' @param sim_pointshape (optional) Integer value defining the shape of the points to be
#'   plotted for the simulated time series of `run_sel`. The value must be a
#'   value between 0 and 25. For all other inputs no points will be plotted.
#'   Default is `sim_pointshape = 1`.
#' @param obs_pointshape (optional) Integer value defining the shape of the points to be
#'   plotted for the observation time series. The value must be a
#'   value between 0 and 25. For all other inputs no points will be plotted.
#'   Default is `obs_pointshape = 1`.
#' @param sim_linetype (optional) Type of the line to be plotted for the
#'   simulated time series. The linetype must be one of 'blank', 'solid',
#'   'dashed', 'dotted', 'dotdash', 'longdash`, or 'twodash'. When 'blank' no
#'   line will be plotted. Default is `sim_linetype = 'solid'`.
#' @param obs_linetype Type of the line to be plotted for the
#'   observation time series. The linetype must be one of 'blank', 'solid',
#'   'dashed', 'dotted', 'dotdash', 'longdash`, or 'twodash'. When 'blank' no
#'   line will be plotted. Default is `obs_linetype = 'dotted'`.
#' @param run_sel_color (optional) Color of the line and points plotted for the
#'   simulation time series `run_sel`. Default `run_sel_color = '#A50F15'`.
#' @param run_ids_color (optional) Colors of the lines plotted for the
#'   simulation time series selected with `run_ids`. The colors are only used
#'   when `plot_bands = FALSE` and individual timeseries are plotted. The color
#'   vector must be of the same length as the selected runs in `run_ids`.
#'   Default `run_ids_color = NULL` where a default color pallete is used.
#' @param obs_color (optional) Color of the line and points of the plotted
#'   observation time series. Default `obs_color = 'black'`.
#' @param band_color (optional) Color of the band plotted fur the `run_ids`. The color is
#'   only used when `plot_bands = TRUE`. Default `band_color = '#CB181D'`.
#' @param band_alpha (optional) Transparency value of the band plotted fur the
#'   `run_ids`. The value is only used when `plot_bands = TRUE`.
#'   The value must be set between 0 and 1. Default `band_alpha = 0.2`.
#' @param run_sel_label (optional) Label which is plotted in the legend to
#'   indicate the selected simulation run `run_sel`. Default is
#'   `run_sel_label = 'Simulation'`.
#' @param obs_label (optional) Label which is plotted in the legend to
#'   indicate the observation time series. Default is
#'   `run_obs = 'Observation'`.
#' @param band_label (optional) Label which is plotted in the legend to
#'   indicate the simulation band for the `run_ids`. Default is
#'   `band_label = 'Simulated range'`.
#' @param x_label (optional) x-Axis label. Default is `x_label = 'Date'`.
#' @param y_label (optional) y-Axis label. Default is `x_label = expression(Discharge~(m^3~s^{-1}))`.
#' @param legend_pos (optional) Position of the legend inside of the plot panel.
#' @param split_years  (optional) Integer value which is used to split the
#'   time series into time intervals of the length `split_years` to plot those
#'   time periods in separate plot panels. This has an advantage for plotting
#'   long time series. Default `split_years = NULL` and the entire time series
#'   is plotted in one plot panel.
#' @param free_y If `split_years` is defined the y-Axis can be scaled individually
#'   for all plot panels if `free_y = TRUE`. Default `free_y = FALSE` and all
#'   plot panels have the same y plot range.
#'
#' @import ggplot2
#'
#' @importFrom dplyr bind_cols filter left_join mutate select %>%
#' @importFrom lubridate days year years
#' @importFrom patchwork wrap_plots
#' @importFrom purrr map map_dbl map2
#' @importFrom tibble tibble
#' @importFrom tidyr pivot_longer
#'
#' @returns A ggplot object of the plotted time series.
#'
#' @export
#' @keywords plot
plot_timeseries <- function(sim, obs = NULL, run_sel = NULL, run_ids = NULL,
                            plot_bands = TRUE, sim_pointshape = 1, obs_pointshape = 1,
                            sim_linetype = 'solid', obs_linetype = 'dotted',
                            run_sel_color = '#A50F15', run_ids_color = NULL,
                            obs_color = 'black', band_color = '#CB181D', band_alpha = 0.2,
                            run_sel_label = 'Simulation', obs_label = 'Observation',
                            band_label = 'Simulated range',
                            x_label = 'Date', y_label = expression(Discharge~(m^3~s^{-1})),
                            legend_pos = c(1,0.99,0.99), split_years = NULL, free_y = FALSE) {
  sim <- check_date_col(sim)
  obs <- check_date_col(obs)

  if(is.null(run_ids) & is.null(run_sel)) {
    stop("At least one of 'run_ids' or 'run_sel' must be provided.")
  }

  if(plot_bands & is.null(run_ids)) {
    message("No 'run_ids' defined. 'plot_bands = TRUE' will be ignored.")
  }

  plt_tbl <- select(sim, date)

  col_pal <- c()

  if(!is.null(obs)) {
    names(obs) <- c('date', 'obs')
    plt_tbl <- left_join(plt_tbl, obs, by = 'date')

    col_pal <- c(col_pal, obs_color)
  }

  nchar_run <- nchar(names(sim)[2]) - 4

  if(!is.null(run_sel)) {
    if(is.numeric(run_sel)) {
      run_sel <- paste0('run_', sprintf(paste0('%0', nchar_run, 'd'), run_sel))
    }
    sim_sel <- sim[, run_sel]
    names(sim_sel) <- 'sim_sel'
    plt_tbl <- bind_cols(plt_tbl, sim_sel)

    col_pal <- c(col_pal, run_sel_color)
  }

  if(!is.null(run_ids)) {
    if(length(run_ids) > 10 & !plot_bands) {
      stop("More than 10 'run_ids' were selected for individual plotting. \n",
           "For more than 10 'run_ids' please use 'plot_bands = TRUE'.")
    }
    if(run_ids[1] != 'all') {
      if(is.numeric(run_ids)) {
        run_ids <- paste0('run_', sprintf(paste0('%0', nchar_run, 'd'), run_ids))
      }
      sim_ids <- sim[, run_ids]
    } else {
      sim_ids <- select(sim, - date)
    }
    if(plot_bands) {
      sim_upr <- apply(sim_ids, 1, max)
      sim_lwr <- apply(sim_ids, 1, min)
      sim_ids <- tibble(date = sim$date, upr = sim_upr, lwr = sim_lwr)
    } else {
      plt_tbl <- bind_cols(plt_tbl, sim_ids)

      if(is.null(run_ids_color)) {
        col_pal <- c(col_pal, c("#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",
                                "#FFFF33", "#A65628", "#F781BF", "#999999",
                                "#1B9E77", "#D9D9D9")[1:length(run_ids)]
        )

      } else if (length(run_ids_color) == length(run_ids)) {
        col_pal <- c(col_pal, run_ids_color)
      } else {
        stop("Please provide the same number of 'run_id_color's",
             " as the number of 'run_ids'.")
      }
    }
  }

  def_linetype <- c(rep(sim_linetype, sum(grepl('sim_sel|run_', names(plt_tbl)))))

  if('obs' %in% names(plt_tbl)) {
    def_linetype <- c(obs_linetype, def_linetype)
  }

  plt_tbl <- plt_tbl %>%
    pivot_longer(., cols = - date) %>%
    mutate(name = ifelse(name == 'sim_sel', run_sel_label, name),
           name = ifelse(name == 'obs', obs_label, name)) %>%
    mutate(name = factor(name, levels = unique(name)))

  obs_pointshape <- check_point_shape(obs_pointshape)
  sim_pointshape <- check_point_shape(sim_pointshape)

  def_pointshape <- c()
  if(obs_label %in% unique(plt_tbl$name)) {
    def_pointshape <- c(def_pointshape, obs_pointshape)
  }
  if(run_sel_label %in% unique(plt_tbl$name)) {
    def_pointshape <- c(def_pointshape, sim_pointshape)
  }
  if(!plot_bands) {
    def_pointshape <- c(def_pointshape, rep(NA, length(run_ids)))
  }

  gg_plt <- ggplot() +
    labs(x = x_label, y = y_label) +
    theme_bw() +
    theme(legend.title = element_blank(),
          legend.position = 'inside',
          legend.position.inside = legend_pos[c(2,3)],
          legend.justification = legend_pos[c(2,3)],
          legend.direction = 'horizontal',
          legend.spacing.y = unit(-0.25, 'cm')
    )

  if(plot_bands & !is.null(run_ids)) {
    gg_plt <- gg_plt +
      geom_line(data = sim_ids, aes(x = date, y = lwr), alpha = 0.2,
                color = band_color) +
      geom_line(data = sim_ids, aes(x = date, y = upr), alpha = 0.2,
                color = band_color) +
      geom_ribbon(data = sim_ids, aes(x = date, ymin = lwr, ymax = upr,
                                      fill = band_label), alpha = 0.2) +
      scale_fill_manual(values = band_color)
  }

  gg_plt <- gg_plt +
    geom_point(data = plt_tbl, aes(x = date, y = value, color = name, shape = name), na.rm=TRUE) +
    geom_line(data = plt_tbl, aes(x = date, y = value, color = name, linetype = name), na.rm=TRUE) +
    scale_color_manual(name = 'name', values = col_pal) +
    scale_linetype_manual(name = 'name', values = def_linetype) +
    scale_shape_manual(values = def_pointshape)

  if(!is.null(split_years)) {
    yrs <- unique(year(plt_tbl$date))
    n_yrs <- max(yrs) - min(yrs)
    start_dates <- c(plt_tbl$date[1],
                     plt_tbl$date[1] +
                       years(seq(split_years, n_yrs, split_years)))
    end_dates <- c(plt_tbl$date[1] +
                     years(seq(split_years, n_yrs + split_years, split_years)) - days(1))
    end_dates <- unique(end_dates)
    gg_plt <- map2(start_dates, end_dates, ~ gg_plt + scale_x_date(limits = c(.x, .y)))

    if(free_y) {
      max_vals <- map2(start_dates, end_dates,
                       ~ filter(plt_tbl, date >= .x & date <= .y)) %>%
        map(., ~select(.x, - date)) %>%
        map(., unlist) %>%
        map_dbl(., ~1.1*max(.x))

      gg_plt <- map2(gg_plt, max_vals, ~ .x + scale_y_continuous(limits = c(0, .y)))
    }

    for(i in 1:length(gg_plt)) {
      if(i != 1) {
        gg_plt[[i]] <- gg_plt[[i]] + theme(axis.title.y = element_blank())
      }
      if(i != legend_pos[1]) {
        gg_plt[[i]] <- gg_plt[[i]] + theme(legend.position = 'none')
      }
      if(i != length(gg_plt)) {
        gg_plt[[i]] <- gg_plt[[i]] + theme(axis.title.x = element_blank())
      }
    }

    gg_plt <- wrap_plots(gg_plt, ncol = 1)
  }

  return(gg_plt)
}

#' Plot Flow Duration Curve (FDC) for Observed and Simulated Data
#'
#' This function computes and plots the Flow Duration Curve (FDC) for observed
#' and simulated discharge data.
#' If multiple simulations are provided, a shaded band (min–max) and median line are shown.
#' If only one simulation is provided, a single line is plotted.
#'
#' @param sim A data frame or matrix of simulated discharge time series.
#' Columns are assumed to represent different simulation runs, and one column
#' should be named "date" for the date/time information.
#' If only one simulation is provided, it will be plotted as a single line.
#' @param obs A data frame with two columns: "date" and "discharge", where "date"
#' contains the date/time information and "discharge" contains the observed discharge values.
#' @param run_ids Optional. A character, numeric or a vector of character strings
#' specifying which simulation run IDs to include (e.g., \code{c("0001", "0002")}).
#' Matching is done by name, so exact character matching is recommended.
#' @param scale_log Logical. If \code{TRUE} (default), a log-10 transformation
#' is applied to the y-axis.
#' @param x_label Label for the x-axis. Defaults to "Exceedance Probability (%)".
#' @param y_label Label for the y-axis. Defaults to "Discharge (log scale)".
#' @param title Plot title. Defaults to "Flow Duration Curve: Observed vs Simulated".
#'
#' @return A \code{ggplot} object showing the flow duration curve with observed and simulated data.
#'
#' @importFrom ggplot2 ggplot aes geom_line geom_ribbon geom_point scale_color_manual
#' scale_fill_manual theme_minimal theme labs element_blank scale_y_log10
#' @importFrom dplyr group_by %>% summarise bind_rows
#' @importFrom tidyr pivot_longer
#' @importFrom stats median
#' @export
#' @examples
#' \dontrun{
#' # Example with simulated and observed time series
#' plot_fdc(sim = sim_data, obs = obs_data, run_ids = c("0001", "0002"))
#' }
#' @keywords plot
#' @seealso \code{\link{calc_fdc}}

plot_fdc <- function(sim, obs, run_ids = NULL, scale_log = TRUE,
                     x_label = "Exceedance Probability (%)",
                     y_label = "Discharge (log scale)",
                     title = "Flow Duration Curve: Observed vs Simulated"){
  # Compute FDCs
  fdc_obs <- calc_fdc(obs)
  fdc_sim <- calc_fdc(sim)
  if (!is.null(run_ids)) {
    fdc_sim <- fdc_sim[,grep(paste(c("p", run_ids), collapse = "|"), names(fdc_sim))]
    if(length(run_ids) != dim(fdc_sim)[2]-1){
      warning("Number of run_ids does not match number of selected simulated runs.
  This is likely because the run_ids match multible runs. If you don't want this, please update run_ids to specify the correct runs using character strings of run IDs.
  For instance, run_ids = 1 should be run_ids = '0001'")
    }
  }
  if(dim(fdc_sim)[2] > 2){
    # Compute bounds for simulated data (e.g., min and max)
    fdc_sim_bounds <- fdc_sim %>%
      pivot_longer(cols = -p, values_to = "discharge") %>%
      group_by(p) %>%
      summarise(
        sim_min = min(discharge, na.rm = TRUE),
        sim_max = max(discharge, na.rm = TRUE),
        sim_median = median(discharge, na.rm = TRUE)
      )
    # Plot
    fig <- ggplot() +
      # Ribbon for min-max bound
      geom_ribbon(data = fdc_sim_bounds, aes(x = p, ymin = sim_min, ymax = sim_max, fill = "Simulated range"), alpha = 0.3) +
      # Median line
      geom_line(data = fdc_sim_bounds, aes(x = p, y = sim_median, color = "Simulated median"), linewidth = 1) +
      # Observed line
      geom_line(data = fdc_obs, aes(x = p, y = discharge, color = "Observed"), linewidth = 1.2) +
      scale_color_manual(values = c("Simulated median" = "#00bfc4", "Observed" = "red")) +
      scale_fill_manual(values = c("Simulated range" = "grey40")) +
      theme_minimal() +
      labs(title = title, x = x_label, y = y_label, color = NULL, fill = NULL)
  } else {
    colnames(fdc_sim) <- c("p", "discharge")
    fdc_obs$type <- "Observed"
    fdc_sim$type <- "Simulated"
    # Combine for plotting
    fdc_combined <- bind_rows(fdc_obs, fdc_sim)
    # Plotting
    fig <- ggplot(fdc_combined, aes(x = p, y = discharge, color = type)) +
      geom_line(size = 1) +
      theme_minimal() +
      labs(title = title, x = x_label, y = y_label) +
      theme(legend.title = element_blank())
  }
  if (scale_log) {
    fig <- fig + scale_y_log10()
  }
  return(fig)
}

#' Plot Precipitation vs. Runoff
#'
#' Creates a dual-axis plot comparing precipitation and runoff over time.
#'
#' @param pcp_file Character string specifying the path to the precipitation data file.
#' The file should contain columns: year (integer), yday (integer), pcp (numeric, in mm).
#' @param flow Data frame with at least two columns: `date` (Date) and `discharge` (numeric, in m³/s).
#' @param x_label Character string for x-axis label. Defaults to "Date".
#' @param y_left Character string for left y-axis label (runoff). Defaults to "Runoff (m³/s)".
#' @param y_right Character string for right y-axis label (precipitation). Defaults to "Precipitation (mm)".
#' @param title Character string for plot title. Defaults to "Precipitation and Runoff".
#' @return A ggplot2 object representing the dual-axis plot.
#' @importFrom readr read_table
#' @importFrom dplyr mutate select filter left_join
#' @importFrom ggplot2 ggplot aes geom_line geom_area scale_y_continuous sec_axis
#'   scale_colour_manual scale_fill_manual labs theme_minimal theme
#' @examples
#' \dontrun{
#' pcp_file_path <- "path/to/my_station.pcp"
#' flow_data <- data.frame(date = as.Date("2023-01-01") + 0:364, discharge = runif(365, 0, 100))
#' plot_pcp_vs_flow(pcp_file_path, flow_data)
#' }
#' @export
#' @keywords plot

plot_pcp_vs_flow <- function(pcp_file, flow,
                             x_label  = "Date",
                             y_left   = "Runoff (m3/s)",
                             y_right  = "Precipitation (mm)",
                             title    = "Precipitation and Runoff"){

  ## Read and prepare precipitation data
  pcp <- suppressWarnings(read_table(pcp_file, skip = 3,     # Skip all non-data lines
                                     col_names = c("year", "yday", "pcp"),
                                     col_types = "iid")) %>%
    mutate(date = as.Date(yday - 1, origin = paste0(year, "-01-01"))) %>%
    select(date, pcp)

  ## Join and clean
  df <- pcp %>%
    filter(date >= min(flow$date) & date <= max(flow$date)) %>%
    left_join(flow, by = "date") %>%
    select(date, pcp, discharge)

  ## Build scaling constants
  max_Q   <- max(df$discharge, na.rm = TRUE)            # peak runoff
  max_P   <- max(df$pcp,       na.rm = TRUE)            # peak rainfall
  df$pcp_scaled <- max_Q - (df$pcp / max_P) * max_Q     # 0 mm == top

  ## Plotting
  ggplot(df, aes(date)) +
    geom_line(
      aes(y = pcp_scaled, colour = "Rainfall"), size = .45
    ) +
    geom_line(
      aes(y = discharge, colour = "Runoff"), size = .45
    ) +
    geom_area(aes(y = discharge,  fill = "Runoff"), alpha = 0.3, show.legend = FALSE) +
    scale_y_continuous(
      name      = y_left,
      limits    = c(0, max_Q * 1.05),
      sec.axis  = sec_axis(
        trans = ~ (max_Q - .) * max_P / max_Q,  # invert the trick
        name  = y_right
      )
    ) +
    scale_colour_manual(values = c(Runoff  = "blue", Rainfall = "forestgreen")) +
    scale_fill_manual(values  = c(Runoff = "blue"))+
    labs(title = title, x = x_label) +
    theme_minimal() +
    theme(
      legend.position = c(0.9, 0.4),
      legend.title = element_blank(),
      axis.title.y.left    = element_text(colour = "blue",  face = "bold"),
      axis.text.y.left     = element_text(colour = "blue"),
      axis.title.y.right   = element_text(colour = "forestgreen", face = "bold"),
      axis.text.y.right    = element_text(colour = "forestgreen"),
      plot.title           = element_text(hjust = .5, face = "bold")
    )
}

#' Plot Calibration and Validation Performance Indexes in Boxplots
#'
#' Creates comparative boxplots and jittered points for calibration and validation
#' performance metrics. The function takes two data frames: one for calibration and
#' one for validation—with a column `run` and additional performance metric columns.
#' It reshapes the data, adds identifiers for type, and produces faceted plots for
#' each metric.
#'
#' @param cal_df A data frame containing calibration results. Must include a `run`
#'   column and one or more performance metric columns.
#' @param val_df A data frame containing validation results. Must include a `run`
#'   column and one or more performance metric columns that match those in `cal_df`.
#'
#' @return A `ggplot` object showing faceted boxplots and jittered values for each
#'   performance metric, comparing calibration vs. validation results.
#'
#' @examples
#' \dontrun{
#' cal <- data.frame(run = 1:10, NSE = runif(10), KGE = runif(10))
#' val <- data.frame(run = 1:10, NSE = runif(10), KGE = runif(10))
#' plot_cal_val(cal, val)
#' }
#'
#' @importFrom dplyr bind_rows
#' @importFrom tidyr pivot_longer
#' @importFrom ggplot2 ggplot aes geom_boxplot geom_point position_jitter
#' facet_wrap theme_bw labs theme element_blank
#'
#' @export
#' @keywords plot

plot_cal_val <- function(cal_df, val_df) {

  # Add a column identifying the type
  cal_df$type <- "Calibration"
  val_df$type <- "Validation"

  # Combine both datasets
  df <- bind_rows(cal_df, val_df) |>
    pivot_longer(
      cols = -c(run, type),
      names_to = "metric",
      values_to = "value"
    )

  fig <- ggplot(df, aes(x = type, y = value, fill = type)) +
    geom_boxplot() +
    geom_point(position = position_jitter(width = 0.1), size = 1, alpha = 0.5) +
    facet_wrap(~metric, scales = "free", nrow = 1) +
    theme_bw() +
    labs(
      y = "Performance index values",
      fill = "Run type"
    ) +
    theme(
      axis.title.x = element_blank(),
      axis.text.x = element_blank(),
      axis.ticks.x = element_blank()
    )

  return(fig)
}

